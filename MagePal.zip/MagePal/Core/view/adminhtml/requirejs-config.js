var config = {
    map: {
        '*': {
            magePalCoreNotificationIcon: 'MagePal_Core/js/notification-icon'
        }
    }
};
