var config = {
    map: {
        '*': {
            magePalGmailSmtpAppValidateConfig: 'MagePal_GmailSmtpApp/js/validate-config'
        }
    }
};
