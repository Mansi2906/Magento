<?php
namespace VDC\Grid\Model\Img;

use Magento\Framework\UrlInterface;
use Magento\Framework\Filesystem;

class Image
{

    protected $subDir = 'label/icon/'; //actual path is pub/media/webkul/image/
 
    protected $urlBuilder;

    protected $fileSystem;
    
    /**
     * @param UrlInterface $urlBuilder
     * @param Filesystem $fileSystem
     */
    public function __construct(
        UrlInterface $urlBuilder,
        Filesystem $fileSystem
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->fileSystem = $fileSystem;
    }

    /**
     * get images base url
     *
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]).$this->subDir;
    }
}