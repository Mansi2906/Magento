<?php 

namespace VDC\Grid\Model;

use Magento\Framework\Model\AbstractModel;

class Grid extends AbstractModel{
	
	protected $_idFieldName = 'uid';
	
	protected function _construct()
	{
		$this->_init('VDC\Grid\Model\ResourceModel\Grid');
	}
	
}
