<?php
namespace VDC\Grid\Model\MultiSelect;
class Status implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        $options = [];
        $options[] = ['label' => 'Readding', 'value' => 'Readding'];
        $options[] = ['label' => 'Playing', 'value' => 'Playing'];
         $options[] = ['label' => 'Cooking', 'value' => 'Cooking'];
        $options[] = ['label' => 'Travelling', 'value' => 'Travelling'];
        return $options;
    }
}