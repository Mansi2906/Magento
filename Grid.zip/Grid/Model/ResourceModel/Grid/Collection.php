<?php 

namespace VDC\Grid\Model\ResourceModel\Grid;
// use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;


class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'uid';
	
	protected function _construct()
	{
		$this->_init('VDC\Grid\Model\Grid', 'VDC\Grid\Model\ResourceModel\Grid');
		// parent::_construct();
	}
}
