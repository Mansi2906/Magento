<?php

namespace VDC\Grid\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Grid extends AbstractDb{
	
	protected function _construct(){
		$this->_init('Custom_grid_list', 'uid');
	}
}


