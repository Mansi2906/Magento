<?php

namespace VDC\Grid\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;

class Edit extends \Magento\Backend\App\Action
{

    protected $resultPageFactory;
	
	protected $GridFactory;
	
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \VDC\Grid\Model\GridFactory $GridFactory,
        \Magento\Framework\Registry $registry
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->GridFactory       = $GridFactory;
        $this->_coreRegistry     = $registry;
        parent::__construct($context);
    }
	
	
    protected function _initAction()
    {
      
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu(' VDC_Grid::grid')
            ->addBreadcrumb(__('Grid'), __('Grid'));
        return $resultPage;
    }
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');        

        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit ') : __('New '),
            $id ? __('Edit ') : __('New ')
        );
        
        $resultPage->getConfig()->getTitle()->prepend(__('Grid'));
        $resultPage->getConfig()->getTitle()
            ->prepend($id ? __('Edit ') : __('New '));

        return $resultPage;
    }
}
