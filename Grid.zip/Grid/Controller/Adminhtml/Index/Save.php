<?php

namespace VDC\Grid\Controller\Adminhtml\Index;
use VDC\Grid\Model\GridFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\File\UploaderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Request\DataPersistorInterface;


class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    private $itemFactory;
    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        UploaderFactory $fileUploaderFactory,
        Filesystem $filesystem,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
		GridFactory $extensionFactory

    ) {
		$this->extensionFactory = $extensionFactory;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_filesystem = $filesystem;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context);
    }

    public function execute()
    {

        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        // echo "<pre>";
        // var_dump($data);die();
        $model = $this->extensionFactory->create();


   		if (isset($data['uid'])) {
            try {
                $id = $data['uid'];
                $model = $model->load($id);
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage(__('This page no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
        }
        if(!empty($data['file'][0]['name']) && isset($data['file'][0]['tmp_name'])) {
           
                $data['file'] = $data['file'][0]['name'];
                
           
        }
        else{
            unset($data['file']);
        }
        $data['multi_select_column']=implode(',',$data['multi_select_column']);
        $model->setData($data['multi_select_column']);
            
        // $selectedOptions = $data['multi_select_column'];
          
        // $arr = (implode(',', $selectedOptions));
            
        // $data['multi_select_column']=$arr;

        $model->setData($data);
        $model->save();
        $this->messageManager->addSuccessMessage(__('Data Saved Successfully..'));

        return $this->resultRedirectFactory->create()->setPath('*/*/index');

    }
}


