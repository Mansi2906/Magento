<?php
namespace VDC\Grid\Controller\Adminhtml\Index;

class Index extends \Magento\Backend\App\Action
{
    
    protected $resultPageFactory;
    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
       
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
      
    }

    public function execute()
    {
    
        $resultPageFactory = $this->resultPageFactory->create();
        $resultPageFactory->getConfig()->getTitle()->prepend(__('Custom Grid'));

        return $resultPageFactory;
    }
}
?>
