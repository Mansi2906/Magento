<?php
namespace Vdcstore\FreeGift\Plugin;

class CartItemRendererPlugin
{
    /**
     * Modify the template of the block
     *
     * @param \Magento\Checkout\Block\Cart\Item\Renderer\Actions\Edit $subject
     * @param string $result
     * @return string
     */
    public function afterGetTemplate(\Magento\Checkout\Block\Cart\Item\Renderer\Actions\Edit $subject, $result)
    {
        return 'Vdcstore_FreeGift::cart/item/renderer/actions/edit.phtml';
    }
}
