<?php

namespace Vdcstore\FreeGift\Plugin;

use Magento\Quote\Model\Quote;

class RemoveGiftItemPlugin
{
    /**
     * Intercept the removeItem method.
     *
     * @param Quote $subject
     * @param string $itemId
     * @return void
     */
    public function beforeRemoveItem(Quote $subject, $itemId)
    {
        $quote = $subject;
        $giftItemId = null;

        // Check if any item in the cart is marked as a gift
        foreach ($quote->getAllItems() as $item) {
            if ($item->getData('description') === 'Gift_Product') {
                $giftItemId = $item->getItemId();
                break;
            }
        }

        if ($giftItemId && $giftItemId !== $itemId) {
            $quote->removeItem($giftItemId);
        }
    }
}
