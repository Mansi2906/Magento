<?php
namespace Vdcstore\FreeGift\Plugin\Cart;

class AbstractCart
{
    /**
     *   Override cart/item/default.phtml file
     *
     * @param \Magento\Checkout\Block\Cart\AbstractCart $subject
     * @param string $result
     * @return string
     */
    public function afterGetItemRenderer(\Magento\Checkout\Block\Cart\AbstractCart $subject, $result)
    {
        $result->setTemplate('Vdcstore_FreeGift::cart/item/default.phtml');
        return $result;
    }
}
