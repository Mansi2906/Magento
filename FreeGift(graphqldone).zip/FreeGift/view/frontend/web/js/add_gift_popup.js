require([
    'jquery',
    'Magento_Ui/js/modal/modal',
    'mage/url',
    'mage/translate'
], function($, modal, urlBuilder, $t) {
    $(document).on('click', '.add-gift-btn', function() {
        $.ajax({
            url: urlBuilder.build('freegift/ajax/getProductDetails'),
            type: 'GET',
            success: function(response) {
                var productGridHtml = '<div class="gift-product-grid">';
                if (response && response.length) {
                    response.forEach(function(product) {
                        if (product.error) {
                            productGridHtml += '<div class="gift-product-grid-item">';
                            productGridHtml += '<strong>' + product.sku + ':</strong> ' + product.error;
                            productGridHtml += '</div>';
                        } else {
                            productGridHtml += '<div class="gift-product-grid-item">';
                            productGridHtml += '<img src="' + product.image + '" alt="' + product.name + '" class="product-image" />';
                            productGridHtml += '<span>' + product.name + '</span>';
                            productGridHtml += '<strike>' + product.priceSymbol + product.price + '</strike>';
                            productGridHtml += '<strong>' + product.priceSymbol + '0.00 </strong>';
                            productGridHtml += '<button class="action-primary add-gift" type="button" data-sku="' + product.sku + '"><span>Add</span></button>';
                            productGridHtml += '</div>';
                        }
                    });
                    productGridHtml += '</div>';
                } else {
                    productGridHtml = $t('No products found.');
                }

                var modalHtml = '<div id="product-modal" class="product-modal">' + productGridHtml + '</div>';
                $('body').append(modalHtml);

                var modalOptions = {
                    type: 'popup',
                    responsive: true,
                    innerScroll: true,
                    buttons: []
                };

                var productModal = modal(modalOptions, $('#product-modal'));

                productModal.openModal();
            },
            error: function() {
                var modalHtml = '<div id="error-modal" class="error-modal">' + $t('An error occurred while fetching the product data.') + '</div>';
                $('body').append(modalHtml);

                var modalOptions = {
                    type: 'popup',
                    responsive: true,
                    innerScroll: true,
                    buttons: []
                };

                var errorModal = modal(modalOptions, $('#error-modal'));
                errorModal.openModal();
            }
        });
    });

    $(document).on('click', '.add-gift', function() {
        var sku = $(this).data('sku');
        
        $.ajax({
            url: urlBuilder.build('freegift/ajax/addGift'),
            type: 'POST',
            data: {
                sku: sku
            },
            success: function(response) {
                location.reload();
            },
            error: function() {
                alert($t('An error occurred while adding the gift item.'));
            }
        });
    });
});
