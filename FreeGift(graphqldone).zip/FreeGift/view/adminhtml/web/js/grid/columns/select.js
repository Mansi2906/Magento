define([
    'underscore',
    'Magento_Ui/js/grid/columns/select'
], function (_, Column) {
    'use strict';
    
    return Column.extend({
        getJobStatusColor: function (row) {            
            if (row.is_active == 1) {
                return 'Active';
            }else if(row.is_active == 0) {
                return 'Deactive';
            }
            return '#303030';
        }
    });
});