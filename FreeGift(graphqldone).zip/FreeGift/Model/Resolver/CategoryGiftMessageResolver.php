<?php
namespace Vdcstore\FreeGift\Model\Resolver;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Vdcstore\FreeGift\Helper\Data;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;

class CategoryGiftMessageResolver implements ResolverInterface
{
    protected $helper;
    protected $productRepository;
    protected $scopeConfig;

    public function __construct(
        Data $helper,
        ProductRepositoryInterface $productRepository,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->helper = $helper;
        $this->productRepository = $productRepository;
        $this->scopeConfig = $scopeConfig;
    }

    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        ?array $value = null,
        ?array $args = null
    ) {
        $isEnabled = $this->helper->isEnable();

        if (!$isEnabled) {
            throw new GraphQlInputException(__('Please enable Free Gift module.'));

        }
        // Step 1: Ensure the correct key for the product ID exists
        $productId = isset($value['entity_id']) ? $value['entity_id'] : null;

        // Step 2: If the product ID is not set, return null
        if (!$productId) {
            return null;
        }

        try {
            // Step 3: Load the product by its ID
            $product = $this->productRepository->getById($productId);

            // Step 4: Validate if product matches item_rule
            $validation = $this->helper->isValidGiftForItemRule($product);

            if ($validation['status']) {
                // Step 5: Check if gift content should be displayed on the category page
                $showGiftOnCategory = $this->scopeConfig->getValue(
                    'FreeGift/notice_for_product_item/gift_content_on_category_item', // path to the configuration field
                    ScopeInterface::SCOPE_STORE // scope (you can change to SCOPE_WEBSITE if needed)
                );

                // Step 6: If gift content is enabled on category page, fetch the content
                if ($showGiftOnCategory) {
                    $categoryPageContent = $this->scopeConfig->getValue(
                        'FreeGift/notice_for_product_item/category_page_content', // path to the category page content
                        ScopeInterface::SCOPE_STORE // scope
                    );

                    // Return the dynamic category page content
                    return __($categoryPageContent);
                } else {
                    // Return a message if the field is disabled
                    return __('The free gift notification is disabled on the category page.');
                }
            }
            else{
                // Return a message when the item does not match the rule
                return __('This product does not match item rule for a free gift.');    
            }
        } catch (\Exception $e) {
            // Handle error or log it
            return null;
        }

        // Step 7: Return null if no gift applies
        return null;
    }
}
