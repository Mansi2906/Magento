<?php
namespace Vdcstore\FreeGift\Model\Resolver;

use Magento\Quote\Model\Quote\Item as QuoteItem;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Quote\Model\QuoteFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\MaskedQuoteIdToQuoteIdInterface;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Vdcstore\FreeGift\Helper\Data;

class FreeGiftCartItems implements ResolverInterface
{
    protected $scopeConfig;
    protected $cartRepository;
    protected $maskedQuoteIdToQuoteId;
    protected $helper;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        CartRepositoryInterface $cartRepository,
        MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId,
        Data $helper,
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->cartRepository = $cartRepository;
        $this->maskedQuoteIdToQuoteId = $maskedQuoteIdToQuoteId;
        $this->helper = $helper;
    }

    public function resolve(
        $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $items = [];

        $isEnabled = $this->helper->isEnable();

        if (!$isEnabled) {
            throw new GraphQlInputException(__('Please enable Free Gift module.'));
    
        }
        if (empty($args['cart_id'])) {
            throw new GraphQlInputException(__('Cart ID is required.'));
        }

        $cartId = $args['cart_id'];

        // Convert masked ID to real quote ID for guests
        try {
            $quoteId = $this->maskedQuoteIdToQuoteId->execute($cartId);
        } catch (\Exception $e) {
            throw new GraphQlInputException(__('Invalid cart ID'));
        }

        $quote = $this->cartRepository->getActive($quoteId);

        $configEnabled = $this->scopeConfig->isSetFlag(
            'FreeGift/notice_for_product_item/gift_content_on_cart_page',
            ScopeInterface::SCOPE_STORE
        );

        if ($configEnabled) {
        $giftMessage = $this->scopeConfig->getValue(
            'FreeGift/notice_for_product_item/cart_page_content',
            ScopeInterface::SCOPE_STORE
        );
        
        }
        else {
            $giftMessage = __('The free gift notification is disabled on the cart page.');
        }

        foreach ($quote->getAllVisibleItems() as $item) {
            /** @var QuoteItem $item */
            if ($item->getData('description') === 'Gift_Product') {
                $items[] = [
                    'item_id' => $item->getItemId(),
                    'name' => $item->getName(),
                    'sku' => $item->getSku(),
                    'qty' => (float) $item->getQty(),
                    'price' => (float) $item->getPrice(),
                    'gift_message' => $giftMessage
                ];
            }
        }

        // If no gift items were added
        if (empty($items)) {
            return [
                [
                    'gift_message' => __('No gift products in the cart.')
                ]
            ];
        }

        return $items;
    }
}
