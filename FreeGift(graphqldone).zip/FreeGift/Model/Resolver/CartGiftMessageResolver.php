<?php
namespace Vdcstore\FreeGift\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Vdcstore\FreeGift\Helper\Data;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;

class CartGiftMessageResolver implements ResolverInterface
{
    protected $quoteRepository;
    protected $quoteIdMaskFactory;
    protected $helper;
    protected $scopeConfig;
    protected $logger;

    public function __construct(
        CartRepositoryInterface $quoteRepository,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        Data $helper,
        ScopeConfigInterface $scopeConfig,
        LoggerInterface $logger
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->helper = $helper;
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
    }

    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        ?array $value = null,
        ?array $args = null
    ) {
        try {
            $isEnabled = $this->helper->isEnable();

            if (!$isEnabled) {
                throw new GraphQlInputException(__('Please enable Free Gift module.'));
    
            }
            if (empty($args['cart_id'])) {
                throw new GraphQlInputException(__('Cart ID is required.'));
            }

            $maskedCartId = $args['cart_id'];
            $isCustomer = !empty($context->getUserId());

            // Load quote
            try {
                if ($isCustomer) {
                    $quote = $this->quoteRepository->get($maskedCartId);
                } else {
                    $maskedModel = $this->quoteIdMaskFactory->create()->load($maskedCartId, 'masked_id');
                    $quoteId = $maskedModel->getQuoteId();

                    if (!$quoteId) {
                        throw new GraphQlInputException(__('Cart ID is not valid.'));
                    }

                    $quote = $this->quoteRepository->get($quoteId);
                }
            } catch (\Exception $e) {
                throw new GraphQlInputException(__('Cart ID is not valid.'));
            }

            $cartItems = $quote->getAllVisibleItems();
            $items = [];

            $ruleMatchedAny = false;

            foreach ($cartItems as $item) {
                $productId = (int)$item->getProductId();
                $giftMessage = __('No gift available for this item.');

                if ($item->getData('description') === 'Gift_Product') {
                    continue;
                }

                try {
                    $product = $item->getProduct();
                    $ruleResult = $this->helper->getCombinedGiftRuleResults($product, $item);
                    if (!empty($ruleResult)) {
                        $ruleMatchedAny = true;
                         if (!empty($ruleResult['status'])) {
                            // Rule is enabled, check config
                            $configEnabled = $this->scopeConfig->isSetFlag(
                                'FreeGift/notice_msg/msg_show_gift_notification',
                                ScopeInterface::SCOPE_STORE
                            );

                            if ($configEnabled) {
                                $giftMessage = $this->scopeConfig->getValue(
                                    'FreeGift/notice_msg/msg_content',
                                    ScopeInterface::SCOPE_STORE
                                ) ?: __('This item qualifies for a free gift!');
                            } else {
                                $giftMessage = __('The free gift notification is disabled on the cart page.');
                            }
                        }
                    }
                } catch (\Exception $e) {
                    $this->logger->error('Gift rule error: ' . $e->getMessage());
                    $giftMessage = __('Error checking gift rule.');
                }
                $freeProductIds = [];

                if (!empty($ruleResult['gift_product_ids']) && is_array($ruleResult['gift_product_ids'])) {
                    foreach ($ruleResult['gift_product_ids'] as $index => $giftJson) {
                        $freeProductIds = [];
                
                        $decoded = json_decode($giftJson, true);
                        if (is_array($decoded)) {
                            $freeProductIds = array_keys($decoded);
                        }
                
                        // Add rule-specific item
                        $items[] = [
                                'free_product_ids' => $freeProductIds,
                                'gift_message' => $giftMessage,
                                'show_button' => (!empty($ruleResult) && !empty($ruleResult['status']) && (!isset($ruleResult['is_active']) || (string)$ruleResult['is_active'] !== '0')) ? true : false
                            ];
                    }
                }
            }

            // If no rules matched at all
            if (!$ruleMatchedAny) {
                return [
                    'items' => [],
                ];
            }

            return [
                'cartId' => $maskedCartId,
                'items' => $items
            ];

        } catch (GraphQlInputException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('CartGiftMessageResolver error: ' . $e->getMessage());
            throw new GraphQlInputException(__('Something went wrong while retrieving cart gift message.'));
        }
    }
}