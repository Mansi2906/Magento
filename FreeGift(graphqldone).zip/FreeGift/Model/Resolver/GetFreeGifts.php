<?php

namespace Vdcstore\FreeGift\Model\Resolver;

use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Vdcstore\FreeGift\Model\ResourceModel\Rules\CollectionFactory;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Vdcstore\FreeGift\Helper\Data;

class GetFreeGifts implements ResolverInterface
{
    protected $collectionFactory;
    protected $helper;

    public function __construct(
        CollectionFactory $collectionFactory,
        Data $helper
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->helper = $helper;
    }

    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $isEnabled = $this->helper->isEnable();

        if (!$isEnabled) {
            throw new GraphQlInputException(__('Please enable Free Gift module.'));
        }
        
        $collection = $this->collectionFactory->create();

        $result = [];

        foreach ($collection as $item) {
            $result[] = [
                'entity_id'         => (int) $item->getEntityId(),
                'name'              => $item->getName(),
                'is_active'         => (bool) $item->getIsActive(),
                'website'           => (int) $item->getWebsite(),
                'customer_groups'   => $item->getCustomerGroups(),
                'apply_for'         => $item->getApplyFor(),
                'description'       => $item->getDescription(),
                'gift_list'         => $this->formatGiftList($item->getGiftList()),
                'conditions'        => json_decode($item->getConditionsSerialized(), true),
                'active_from'       => $item->getActiveFrom(),
                'active_to'         => $item->getActiveTo(),
            ];
        }

        return $result;
    }
    protected function formatGiftList($json)
    {
        $decoded = json_decode($json, true);
        $result = [];

        foreach ($decoded as $productId => $qty) {
            $result[] = [
                'product_id' => (int)$productId,
                'qty' => (int)$qty
            ];
        }

        return $result;
    }

}
