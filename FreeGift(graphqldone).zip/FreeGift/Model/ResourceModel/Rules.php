<?php
namespace Vdcstore\FreeGift\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Rules
 *
 * Resource model for the Rules entity.
 */
class Rules extends AbstractDb
{
    /**
     * Initialize the resource model.
     */
    protected function _construct()
    {
        $this->_init('vdcstore_freegift', 'entity_id');
    }
}
