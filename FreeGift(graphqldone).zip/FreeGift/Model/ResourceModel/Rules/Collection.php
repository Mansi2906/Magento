<?php
namespace Vdcstore\FreeGift\Model\ResourceModel\Rules;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * Collection class for managing Rules entities.
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize the collection model and resource model.
     */
    protected function _construct()
    {
        $this->_init(
            \Vdcstore\FreeGift\Model\Rules::class,
            \Vdcstore\FreeGift\Model\ResourceModel\Rules::class
        );
    }
}
