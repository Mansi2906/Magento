<?php
namespace Vdcstore\FreeGift\Model;

use Vdcstore\FreeGift\Model\ResourceModel\Rules as RuleResourceModel;
use Magento\Quote\Model\Quote\Address;
use Magento\Rule\Model\AbstractModel;

/**
 * Class Rules
 *
 * Model for the Rules entity.
 */
class Rules extends \Magento\Rule\Model\AbstractModel
{
    /**
     * @var string
     */
    protected $_eventPrefix = 'Vdcstore_FreeGift';

    /**
     * @var string
     */
    protected $_eventObject = 'rule';

    /**
     * @var \Magento\CatalogRule\Model\Rule\Condition\CombineFactory
     */
    protected $condCombineFactory;

    /**
     * @var \Magento\SalesRule\Model\Rule\Condition\CombineFactory
     */
    protected $condProdCombineF;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var array
     */
    protected $validatedAddresses = [];

    /**
     * @var array|null
     */
    protected $_selectProductIds;

    /**
     * @var array|null
     */
    protected $_displayProductIds;

    /**
     * Initialize the model.
     *
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate
     * @param \Magento\CatalogRule\Model\Rule\Condition\CombineFactory $condCombineFactory
     * @param \Magento\SalesRule\Model\Rule\Condition\CombineFactory $condProdCombineF
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\CatalogRule\Model\Rule\Condition\CombineFactory $condCombineFactory,
        \Magento\SalesRule\Model\Rule\Condition\CombineFactory $condProdCombineF,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->condCombineFactory = $condCombineFactory;
        $this->condProdCombineF = $condProdCombineF;
        $this->storeManager = $storeManager;
        $this->_init(RuleResourceModel::class);
        $this->setIdFieldName('entity_id');
        parent::__construct($context, $registry, $formFactory, $localeDate, $resource, $resourceCollection, $data);
    }

    /**
     * Determines if called from ItemRuleConditions.
     *
     * @return bool
     */
    private function isFromItemRuleConditions()
    {
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 10);
    
        foreach ($backtrace as $trace) {
            if (isset($trace['file']) && strpos($trace['file'], 'ItemRuleConditions.php') !== false) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get the conditions instance.
     *
     * @return \Magento\Rule\Model\Condition\Combine
     */
    public function getConditionsInstance()
    {
        return $this->isFromItemRuleConditions()
            ? $this->condCombineFactory->create()
            : $this->condProdCombineF->create();
    }
    
    /**
     * Get the actions instance.
     *
     * @return \Magento\Rule\Model\Condition\Combine
     */
    public function getActionsInstance()
    {
        return $this->getConditionsInstance();
    }

    /**
     * Check if the rule is valid for a given address.
     *
     * @param Address|int $address
     * @return bool
     */
    public function hasIsValidForAddress($address)
    {
        $addressId = $this->_getAddressId($address);
        return isset($this->validatedAddresses[$addressId]) ? true : false;
    }

    /**
     * Set the validation result for a given address.
     *
     * @param Address|int $address
     * @param bool $validationResult
     * @return $this
     */
    public function setIsValidForAddress($address, $validationResult)
    {
        $addressId = $this->_getAddressId($address);
        $this->validatedAddresses[$addressId] = $validationResult;
        return $this;
    }

    /**
     * Get the validation result for a given address.
     *
     * @param Address|int $address
     * @return bool
     */
    public function getIsValidForAddress($address)
    {
        $addressId = $this->_getAddressId($address);
        return isset($this->validatedAddresses[$addressId]) ? $this->validatedAddresses[$addressId] : false;
    }

    /**
     * Get the ID for an address.
     *
     * @param Address|int $address
     * @return int
     */
    private function _getAddressId($address)
    {
        if ($address instanceof Address) {
            return $address->getId();
        }
        return $address;
    }

    /**
     * Get the conditions fieldset ID.
     *
     * @param string $formName
     * @return string
     */
    public function getConditionsFieldSetId($formName = '')
    {
        return $formName . 'rule_conditions_fieldset_' . $this->getId();
    }

    /**
     * Get the actions fieldset ID.
     *
     * @param string $formName
     * @return string
     */
    public function getActionFieldSetId($formName = '')
    {
        return $formName . 'rule_actions_fieldset_' . $this->getId();
    }

    /**
     * Get the websites map.
     *
     * @return array
     */
    protected function _getWebsitesMap()
    {
        $map = [];
        $websites = $this->storeManager->getWebsites();
        foreach ($websites as $website) {
            if ($website->getDefaultStore() === null) {
                continue;
            }
            $map[$website->getId()] = $website->getDefaultStore()->getId();
        }
        return $map;
    }
}
