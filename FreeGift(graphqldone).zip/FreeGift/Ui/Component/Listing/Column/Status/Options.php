<?php
namespace Vdcstore\FreeGift\Ui\Component\Listing\Column\Status;

/**
 * Class Options
 *
 * Create a option for job status
 */
class Options implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Retrieve the list of behavior options as an array.
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options = [];
        $options[] = ['label' => 'Deactive', 'value' => 0];
        $options[] = ['label' => 'Active', 'value' => 1];
        
        return $options;
    }
}
