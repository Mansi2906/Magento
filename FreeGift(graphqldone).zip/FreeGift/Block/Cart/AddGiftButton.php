<?php
namespace Vdcstore\FreeGift\Block\Cart;

use Magento\Framework\View\Element\Template;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Catalog\Model\ProductFactory;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Store\Model\StoreManagerInterface;
use Vdcstore\FreeGift\Model\RulesFactory;
use Vdcstore\FreeGift\Helper\Data;

class AddGiftButton extends Template
{
    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;

    /**
     * @var ProductFactory
     */
    protected $productFactory;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var RulesFactory
     */
    protected $giftRuleFactory;
    
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @param \Magento\Framework\App\Http\Context $_httpContext
     * @param Template\Context $context
     * @param ManagerInterface $messageManager
     * @param ProductFactory $productFactory
     * @param CustomerSession $customerSession
     * @param CheckoutSession $checkoutSession
     * @param StoreManagerInterface $storeManager
     * @param RulesFactory $giftRuleFactory
     * @param TimezoneInterface $timezone
     * @param Data $helper
     */
    public function __construct(
        \Magento\Framework\App\Http\Context $_httpContext,
        Template\Context $context,
        ManagerInterface $messageManager,
        ProductFactory $productFactory,
        CustomerSession $customerSession,
        CheckoutSession $checkoutSession,
        StoreManagerInterface $storeManager,
        RulesFactory $giftRuleFactory,
        TimezoneInterface $timezone,
        Data $helper,
    ) {
        $this->httpContext = $_httpContext;
        $this->messageManager = $messageManager;
        $this->productFactory = $productFactory;
        $this->customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
        $this->storeManager = $storeManager;
        $this->giftRuleFactory = $giftRuleFactory;
        $this->timezone = $timezone;
        $this->helper = $helper;
        parent::__construct($context);
    }

    /**
     * Prepares the block before rendering HTML.
     *
     * Displays a success message if the gift button is visible and no gift has been added to the cart.
     *
     * @return $this
     */
    public function _beforeToHtml()
    {
        $isMessageShow = $this->helper->getNoticeConfig('msg_show_gift_notification');
        if ($isMessageShow) {
            if ($this->shouldShowGiftButton()['status'] && !$this->isGiftAdded()) {
                $message = $this->helper->getNoticeConfig('msg_content');
                $this->messageManager->addSuccessMessage($message);
                return parent::_beforeToHtml();
            }
        }
    }

    /**
     * Check if the feature is enabled.
     *
     * @return bool
     */
    public function isEnable()
    {
        return $this->helper->generalConfig('enable');
    }
    
    /**
     * Get Gift Button Design.
     *
     * @param string $field
     * @return string
     */
    public function getGiftButtonDesign($field)
    {
        return $this->helper->btnDesignConfig($field);
    }

    /**
     * Check the gift added or not.
     *
     * @return bool
     */
    public function isGiftAdded()
    {
        $cartItems = $this->checkoutSession->getQuote()->getAllItems();
        foreach ($cartItems as $item) {
            if ($item->getData('description') == 'Gift_Product') {
                return true;
            }
        }
    }

    /**
     * Check the rule is valid or not with the product.
     *
     * @return array
     */
    public function shouldShowGiftButton()
    {
        $cartItems = $this->checkoutSession->getQuote()->getAllItems();
        $mergedLogData = ['status' => true, 'gift_product_ids' => [], 'cart_item_id' => []];
    
        foreach ($cartItems as $cartItem) {
            if ($cartItem->getData('description') === 'Gift_Product') {
                return ['status' => false, 'gift_product_ids' => [], 'cart_item_id' => []];
            }
    
            $giftRuleData = $this->helper->getCombinedGiftRuleResults($cartItem->getProduct(), $cartItem);
            
            if (!empty($giftRuleData['gift_product_ids'])) {
                foreach ($giftRuleData['gift_product_ids'] as $giftProductId) {
                    $decodedIds = json_decode($giftProductId, true);
                    if (is_array($decodedIds)) {
                        $mergedLogData['gift_product_ids'] = array_replace(
                            $mergedLogData['gift_product_ids'],
                            $decodedIds
                        );
                    }
                }
            }
    
            if (!empty($giftRuleData['cart_item_ids'])) {
                $mergedLogData['cart_item_id'] = array_unique(array_merge(
                    $mergedLogData['cart_item_id'],
                    $giftRuleData['cart_item_ids']
                ));
            }
        }
        $mergedLogData['status'] = !empty($mergedLogData['gift_product_ids']);

        $this->checkoutSession->setData('free_gift_data', $mergedLogData);

        return $mergedLogData;
    }

    /**
     * Get the current customer group
     */
    public function getCurrentCustomerGroup()
    {
        $isLoggedIn = $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);
        if ($isLoggedIn) {
             $currentGroupId = $this->customerSession->getCustomer()->getGroupId();
        } else {
            $currentGroupId = 0;
        }
        return $currentGroupId;
    }
}
