<?php
namespace Vdcstore\FreeGift\Block;

use Magento\Msrp\Helper\Data as DefaultHelper;
use Magento\Framework\View\Element\Template;
use Vdcstore\FreeGift\Helper\Data as FreeGiftHelper;

class HeperBlock extends Template
{
    /**
     * @var FreeGiftHelper
     */
    protected $helper;

    /**
     * @var DefaultHelper
     */
    protected $defaultHelper;

    /**
     * Constructor
     *
     * @param Template\Context $context
     * @param FreeGiftHelper $helper
     * @param DefaultHelper $defaultHelper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        FreeGiftHelper $helper,
        DefaultHelper $defaultHelper,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->defaultHelper = $defaultHelper;
        parent::__construct($context, $data);
    }

    /**
     * Method to check this product is valide or not for gift
     *
     * @param Product $product
     * @return array
     */
    public function isValidGiftForItemRule($product)
    {
        return $this->helper->isValidGiftForItemRule($product);
    }

    /**
     * Get product notice configuration
     *
     * @param string $field
     * @return string
     */
    public function getProductItemNoticeConfig($field)
    {
        return $this->helper->getProductItemNoticeConfig($field);
    }

    /**
     * Get content for show befor order
     *
     * @param object $product
     * @return string
     */
    public function isShowBeforeOrderConfirm($product)
    {
        return $this->defaultHelper->isShowBeforeOrderConfirm($product);
    }

    /**
     * Get content for show befor order
     *
     * @param object $product
     * @return string
     */
    public function isMinimalPriceLessMsrp($product)
    {
        return $this->defaultHelper->isMinimalPriceLessMsrp($product);
    }
}
