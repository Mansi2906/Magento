<?php
namespace Vdcstore\FreeGift\Block\Adminhtml\ManageRules;

use Magento\Backend\Block\Widget\Container;
use Magento\Backend\Block\Widget\Button\SplitButton;
use Magento\Backend\Block\Widget\Context;

class SplitButtonAction extends Container
{
    /**
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);

        $addButtonProps = [
            'id' => 'add_new_rule',
            'label' => __('Add New Rule'),
            'class' => 'add',
            'class_name' => SplitButton::class,
            'options' => $this->_getCreateRuleActionListOptions(),
        ];
        $this->buttonList->add('add_new', $addButtonProps);
    }

    /**
     * Retrieve options for 'CreateRleActionList' split button
     *
     * @return array
     */
    protected function _getCreateRuleActionListOptions()
    {
        $splitButtonOptions = [
            'item_rule' => [
                'label' => __('Item Rule'),
                'onclick' => 'window.location.href="' . $this->getUrl('freegift/managerules/additemrule') . '"'
            ],
            'cart_rule' => [
                'label' => __('Cart Rule'),
                'onclick' => 'window.location.href="' . $this->getUrl('freegift/managerules/addcartrule') . '"'
            ],
        ];

        return $splitButtonOptions;
    }
}
