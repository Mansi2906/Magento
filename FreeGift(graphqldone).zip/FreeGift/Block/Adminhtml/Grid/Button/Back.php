<?php
namespace Vdcstore\FreeGift\Block\Adminhtml\Grid\Button;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Back extends Generic implements ButtonProviderInterface
{
    /**
     * Execute method for get button data
     */
    public function getButtonData()
    {
        return [
            'label' => __('Back'),
            'class' => 'back',
            'sort_order' => 10,
            'on_click' => sprintf("location.href = '%s';", $this->getBackUrl())
        ];
    }

    /**
     * Execute method for back url
     */
    public function getBackUrl()
    {
        return $this->getUrl('*/*/');
    }
}
