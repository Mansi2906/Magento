<?php
namespace Vdcstore\FreeGift\Block\Adminhtml\Grid\Button;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Reset extends Generic implements ButtonProviderInterface
{
    /**
     * Execute method for get button data
     */
    public function getButtonData()
    {
        return [
            'label' => __('Reset'),
            'class' => 'reset',
            'sort_order' => 20,
            'on_click' => 'location.reload();',
        ];
    }
}
