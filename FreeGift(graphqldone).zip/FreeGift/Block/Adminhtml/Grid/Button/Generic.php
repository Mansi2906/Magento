<?php
namespace Vdcstore\FreeGift\Block\Adminhtml\Grid\Button;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;

class Generic
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * Constructor
     *
     * @param Context $context
     * @param Registry $registry
     */
    public function __construct(
        Context $context,
        Registry $registry
    ) {
        $this->urlBuilder = $context->getUrlBuilder();
        $this->registry = $registry;
    }

    /**
     * Execute method for get id
     */
    public function getId()
    {
        $contact = $this->registry->registry('entity_id');
        return $contact ? $contact->getId() : null;
    }

    /**
     * Execute method for get url
     *
     * @param string $route
     * @param array $params
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->urlBuilder->getUrl($route, $params);
    }
}
