<?php
namespace Vdcstore\FreeGift\Helper;

use Magento\Catalog\Model\Product;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Vdcstore\FreeGift\Model\RulesFactory;

class Data extends AbstractHelper
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    
    /**
     * @var CustomerSession
     */
    protected $customerSession;
    
    /**
     * @var TimezoneInterface
     */
    protected $timezone;
    
    /**
     * @var RulesFactory
     */
    protected $giftRuleFactory;

    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;
    
    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Http\Context $_httpContext
     * @param Context $context
     * @param StoreManagerInterface $storeManager
     * @param CustomerSession $customerSession
     * @param TimezoneInterface $timezone
     * @param RulesFactory $giftRuleFactory
     */
    public function __construct(
        \Magento\Framework\App\Http\Context $_httpContext,
        Context $context,
        StoreManagerInterface $storeManager,
        CustomerSession $customerSession,
        TimezoneInterface $timezone,
        RulesFactory $giftRuleFactory,
    ) {
        parent::__construct($context);
        $this->httpContext = $_httpContext;
        $this->storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->giftRuleFactory = $giftRuleFactory;
        $this->timezone = $timezone;
    }

    /**
     * Get store configuration value
     *
     * @param string $field
     * @param string|null $storeId
     * @return mixed
     */
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * Get general config
     *
     * @param string $field
     * @param string|null $storeId
     * @return bool
     */
    public function generalConfig($field, $storeId = null)
    {
        return $this->getConfigValue('FreeGift/general/' . $field, $storeId);
    }

    /**
     * Get Cart page Notification config
     *
     * @param string $field
     * @param string|null $storeId
     * @return bool
     */
    public function getNoticeConfig($field, $storeId = null)
    {
        return $this->getConfigValue('FreeGift/notice_msg/' . $field, $storeId);
    }

    /**
     * Get Notice config at cart page
     *
     * @param string $field
     * @param string|null $storeId
     * @return bool
     */
    public function getProductItemNoticeConfig($field, $storeId = null)
    {
        return $this->getConfigValue('FreeGift/notice_for_product_item/' . $field, $storeId);
    }

    /**
     * Get button design config
     *
     * @param string $field
     * @param string|null $storeId
     * @return string
     */
    public function btnDesignConfig($field, $storeId = null)
    {
        return $this->getConfigValue('FreeGift/btn_design/' . $field, $storeId);
    }

    /**
     * Check if the Free Gift feature is enabled
     *
     * @return bool
     */
    public function isEnable()
    {
        return $this->generalConfig('enable');
    }

    /**
     * Check if the gift rule is valid for the product
     *
     * @param object $product
     * @return bool
     */
    public function isValidGiftForItemRule($product)
    {
        $matchedRuleIds = [];
        $cartItemId = [];

        if ($this->isEnable()) {
            $currentTime = $this->timezone->date()->format('Y-m-d H:i:s');
            
            $ruleCollection = $this->giftRuleFactory->create()->getCollection();
            
            $ruleCollection->addFieldToFilter('is_active', ['eq' => 1])
            ->addFieldToFilter('active_from', ['lteq' => $currentTime])
            ->addFieldToFilter('active_to', ['gteq' => $currentTime])
            ->addFieldToFilter('apply_for', ['eq' => 'item_rule']);
        
            if (!empty($ruleCollection->getData())) {
                foreach ($ruleCollection as $rule) {
                    
                    $curWebsite = $this->getCurrentWebsite();
                    $curCustgroup = $this->getCurrentCustomerGroup();
                    
                    if (in_array($curWebsite, explode(',', $rule->getWebsite())) &&
                    in_array($curCustgroup, explode(',', $rule->getCustomerGroups()))) {
                
                        if ($rule->getConditions()->validate($product)) {
                            $cartItemId[] = $product->getEntityId();
                            $matchedRuleIds[] = $rule->getGiftList();
                        }
                    }
                }
            }
        }
        return [
            'status' => !empty($matchedRuleIds),
            'gift_product_ids' => $matchedRuleIds,
            'cart_item_id' => $cartItemId
        ];
    }

    /**
     * Check if the gift rule is valid for the cart page
     *
     * @param object $item
     * @return bool
     */
    public function isValidGiftRule($item)
    {
        $matchedRuleIds = [];
        $cartItemId = [];

        if ($this->isEnable()) {
            $currentTime = $this->timezone->date()->format('Y-m-d H:i:s');
            
            $ruleCollection = $this->giftRuleFactory->create()->getCollection();
            $ruleCollection->addFieldToFilter('is_active', ['eq' => 1])
            ->addFieldToFilter('active_from', ['lteq' => $currentTime])
            ->addFieldToFilter('active_to', ['gteq' => $currentTime]);

            if (!empty($ruleCollection->getData())) {
                foreach ($ruleCollection as $rule) {
                    
                    $curWebsite = $this->getCurrentWebsite();
                    $curCustgroup = $this->getCurrentCustomerGroup();
                    
                    if (in_array($curWebsite, explode(',', $rule->getWebsite())) &&
                    in_array($curCustgroup, explode(',', $rule->getCustomerGroups()))) {
                
                        if ($rule->getConditions()->validate($item)) {
                            $cartItemId[] = $item->getProduct()->getEntityId();
                            $matchedRuleIds[] = $rule->getGiftList();
                        }
                    }
                }
            }
        }
        return [
            'status' => !empty($matchedRuleIds),
            'gift_product_ids' => $matchedRuleIds,
            'cart_item_id' => $cartItemId
        ];
    }

    /**
     * Check if any gift rule is valid and return combined results for cart page
     *
     * @param object $product
     * @param object $item
     * @return array
     */
    public function getCombinedGiftRuleResults($product, $item)
    {
        // Call both functions
        $itemRuleResult = $this->isValidGiftForItemRule($product);
        $cartRuleResult = $this->isValidGiftRule($item);

        // Combine the results
        $combinedResult = [
            'status' => $itemRuleResult['status'] || $cartRuleResult['status'],
            'gift_product_ids' => array_unique(
                array_merge($itemRuleResult['gift_product_ids'], $cartRuleResult['gift_product_ids'])
            ),
            'cart_item_ids' => array_unique(
                array_merge($itemRuleResult['cart_item_id'], $cartRuleResult['cart_item_id'])
            )
        ];

        return $combinedResult;
    }

    /**
     * Get the current website ID
     *
     * @return int
     */
    private function getCurrentWebsite()
    {
        return $this->storeManager->getWebsite()->getWebsiteId();
    }

    /**
     * Get the current customer group ID
     *
     * @return int
     */
    private function getCurrentCustomerGroup()
    {
        $isLoggedIn = $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);
        if ($isLoggedIn) {
             $currentGroupId = $this->customerSession->getCustomer()->getGroupId();
        } else {
            $currentGroupId = 0;
        }
        return $currentGroupId;
    }
}
