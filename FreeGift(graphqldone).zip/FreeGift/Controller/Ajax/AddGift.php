<?php
namespace Vdcstore\FreeGift\Controller\Ajax;

use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Cart;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface;

class AddGift extends Action
{
    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var Cart
     */
    protected $cart;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * AddGift constructor.
     *
     * @param Context $context
     * @param ProductRepository $productRepository
     * @param Cart $cart
     * @param CheckoutSession $checkoutSession
     * @param JsonFactory $resultJsonFactory
     * @param ManagerInterface $messageManager
     */
    public function __construct(
        Context $context,
        ProductRepository $productRepository,
        Cart $cart,
        CheckoutSession $checkoutSession,
        JsonFactory $resultJsonFactory,
        ManagerInterface $messageManager,
    ) {
        $this->productRepository = $productRepository;
        $this->cart = $cart;
        $this->checkoutSession = $checkoutSession;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->messageManager = $messageManager;
        parent::__construct($context);
    }

    /**
     * Execute method to add a gift product to the cart.
     *
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute()
    {
        if ($this->isGiftAdded() != true) {
            $sku = $this->getRequest()->getParam('sku');
            $resultJson = $this->resultJsonFactory->create();
            try {
                $product = $this->productRepository->get($sku);
                $quoteItem = $this->cart->getQuote()->addProduct($product, 1);

                $quoteItem->setCustomPrice(0);
                $quoteItem->setOriginalCustomPrice(0);
                $quoteItem->setQty(1);
                $quoteItem->setIsQtyDecimal(false);
                $quoteItem->setData('description', 'Gift_Product');

                $this->cart->getQuote()->save();
                $this->cart->save();

                $this->messageManager->addSuccessMessage('Gift item added Successfully.');
                return $resultJson->setData(['success' => true, 'message' => 'Gift item added Successfully.']);
            } catch (\Exception $e) {
                $this->messageManager->addSuccessMessage('Failed to add gift item, Please try again later.');
                return $resultJson->setData([
                    'success' => false,
                    'message' => 'Failed to add gift item, Please try again later.'
                ]);
            }
        }
    }

    /**
     * Check the gift added or not.
     *
     * @return bool
     */
    public function isGiftAdded()
    {
        $cartItems = $this->checkoutSession->getQuote()->getAllItems();
        foreach ($cartItems as $item) {
            if ($item->getData('description') == 'Gift_Product') {
                return true;
            }
        }
    }
}
