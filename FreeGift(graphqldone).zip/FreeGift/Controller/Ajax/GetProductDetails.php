<?php
namespace Vdcstore\FreeGift\Controller\Ajax;

use Magento\Catalog\Helper\Image as ImageHelper;
use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\StoreManagerInterface;
use Vdcstore\FreeGift\Model\ResourceModel\Rules\CollectionFactory;
use Vdcstore\FreeGift\Block\Cart\AddGiftButton;

class GetProductDetails extends Action
{
    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var ImageHelper
     */
    protected $imageHelper;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var AddGiftButton
     */
    protected $matcheData;

    /**
     * Constructor
     *
     * @param Context $context
     * @param ProductRepository $productRepository
     * @param CheckoutSession $checkoutSession
     * @param JsonFactory $jsonFactory
     * @param ImageHelper $imageHelper
     * @param StoreManagerInterface $storeManager
     * @param CollectionFactory $collectionFactory
     * @param AddGiftButton $matcheData
     */
    public function __construct(
        Context $context,
        ProductRepository $productRepository,
        CheckoutSession $checkoutSession,
        JsonFactory $jsonFactory,
        ImageHelper $imageHelper,
        StoreManagerInterface $storeManager,
        CollectionFactory $collectionFactory,
        AddGiftButton $matcheData
    ) {
        $this->productRepository = $productRepository;
        $this->checkoutSession = $checkoutSession;
        $this->jsonFactory = $jsonFactory;
        $this->imageHelper = $imageHelper;
        $this->storeManager = $storeManager;
        $this->collectionFactory = $collectionFactory;
        $this->matcheData = $matcheData;
        parent::__construct($context);
    }

    /**
     * Execute the controller action to fetch product details.
     *
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute()
    {
        $matchedRuleData = $this->checkoutSession->getData('free_gift_data');

        $cartItemId = $matchedRuleData['cart_item_id'];
        $giftProductIds = $matchedRuleData['gift_product_ids'];
        
        $ids = [];
        $result = [];
        if (!empty($giftProductIds)) {
            
            $ids = $giftProductIds;
            asort($ids);
            $ids = array_keys($ids);
            $ids = array_diff($ids, $cartItemId);
            
            foreach ($ids as $sku) {
                try {
                    $store = $this->_getStore();
                    $product = $this->productRepository->getById($sku);
                    $imageUrl = $this->imageHelper->init($product, 'product_base_image')->getUrl();

                    $result[] = [
                        'sku' => $product->getSku(),
                        'name' => $product->getName(),
                        'price' => $product->getPrice(),
                        'priceSymbol' => $store->getBaseCurrency()->getCurrencySymbol(),
                        'image' => $imageUrl
                    ];
                } catch (NoSuchEntityException $e) {
                    $result[] = ['sku' => $sku, 'error' => __('Product not found.')];
                }
            }
        }

        $jsonResult = $this->jsonFactory->create();
        return $jsonResult->setData($result);
    }

    /**
     * Get the current store instance.
     *
     * @return Store
     */
    protected function _getStore()
    {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return $this->storeManager->getStore($storeId);
    }
}