<?php
namespace Vdcstore\FreeGift\Controller\Adminhtml\ManageRules;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Framework\View\LayoutFactory;

class Grids extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Controller\Result\RawFactory
     */
    protected $resultRawFactory;

    /**
     * @var \Magento\Framework\View\LayoutFactory
     */
    protected $layoutFactory;

    /**
     * @param Rawfactory    $resultRawFactory
     * @param LayoutFactory $layoutFactory
     * @param Context       $context
     */
    public function __construct(
        Rawfactory $resultRawFactory,
        LayoutFactory $layoutFactory,
        Context $context
    ) {
        $this->resultRawFactory = $resultRawFactory;
        $this->layoutFactory = $layoutFactory;
        parent::__construct($context);
    }

    /**
     * Execute method for Edit
     */
    public function execute()
    {
        $resultRaw = $this->resultRawFactory->create();
        return $resultRaw->setContents(
            $this->layoutFactory->create()->createBlock(
                \Vdcstore\FreeGift\Block\Adminhtml\Tab\Productgrid::class,
                'vdcstore.custom.tab.productgrid'
            )->toHtml()
        );
    }
}
