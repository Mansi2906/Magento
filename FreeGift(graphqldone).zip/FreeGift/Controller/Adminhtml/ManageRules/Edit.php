<?php
namespace Vdcstore\FreeGift\Controller\Adminhtml\ManageRules;

use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Registry;
use Vdcstore\FreeGift\Model\ResourceModel\Rules\Collection;

class Edit extends Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var Registry
     */
    protected $coreRegistry;

    /**
     * @var Collection
     */
    protected $cartRuleFactory;

    /**
     * Constructor
     *
     * @param Action\Context $context
     * @param PageFactory $resultPageFactory
     * @param Registry $coreRegistry
     * @param Collection $cartRuleFactory
     */
    public function __construct(
        Action\Context $context,
        PageFactory $resultPageFactory,
        Registry $coreRegistry,
        Collection $cartRuleFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->coreRegistry = $coreRegistry;
        $this->cartRuleFactory = $cartRuleFactory;
    }

    /**
     * Execute method for Edit
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('entity_id');
        $model = $this->cartRuleFactory->create();

        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addErrorMessage(__('This cart rule no longer exists.'));
                return $this->_redirect('*/*/');
            }

            $this->_coreRegistry->register('current_promo_catalog_rule', $model);
        }

        $this->coreRegistry->register('current_cart_rule', $model);
        $resultPage = $this->resultPageFactory->create();
        return $resultPage;
    }
}
