<?php
namespace Vdcstore\FreeGift\Controller\Adminhtml\ManageRules;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Backend\Model\Session as BackendSession;
use Vdcstore\FreeGift\Model\RulesFactory;
use Vdcstore\FreeGift\Model\ResourceModel\Rules\CollectionFactory;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var RulesFactory
     */
    protected $rulefactory;
    
    /**
     * @var TimezoneInterface
     */
    private $localeDate;
    
    /**
     * @var BackendSession
     */
    protected $backendSession;
    
    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;
    
    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     * @param TimezoneInterface $localeDate
     * @param BackendSession $backendSession
     * @param RulesFactory $rulefactory
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        TimezoneInterface $localeDate,
        BackendSession $backendSession,
        RulesFactory $rulefactory,
        CollectionFactory $collectionFactory
    ) {
        $this->rulefactory = $rulefactory;
        $this->dataPersistor = $dataPersistor;
        $this->localeDate = $localeDate;
        $this->backendSession = $backendSession;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }

    /**
     * Execute method for save job
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            $data = $this->getRequest()->getPostValue();
            
            if (isset($data['general'])) {
                if (isset($data['general']['entity_id']) && isset($data['gift_list'])) {
                    unset($data['general']['gift_list']);
                }
                if (isset($data['general']['entity_id']) && isset($data['conditions_serialized'])) {
                    unset($data['general']['conditions_serialized']);
                }
                
                $data = array_merge($data, $data['general']);
                unset($data['general']);
            }
            
            // Format the date fields
            $jobTime = new \DateTime($data['active_from']);
            $data['active_from'] = $jobTime->format('Y-m-d');
            $jobTime = new \DateTime($data['active_to']);
            $data['active_to'] = $jobTime->format('Y-m-d');
            
            if ($data['customer_groups']) {
                $data['customer_groups'] = implode(",", $data['customer_groups']);
            }
            if ($data['website']) {
                $data['website'] = implode(",", $data['website']);
            }

            $model = $this->rulefactory->create();

            // Check if entity_id exists to load the existing record
            if (isset($data['entity_id']) && $data['entity_id']) {
                try {
                    $model = $model->load($data['entity_id']);
                    if (!$model->getId()) {
                        throw new LocalizedException(__('The record with ID %1 does not exist.', $data['entity_id']));
                    }
                } catch (LocalizedException $e) {
                    $this->messageManager->addErrorMessage(__('This page no longer exists.'));
                    return $resultRedirect->setPath('*/*/');
                }
            }

            if (isset($data['rule'])) {
                $data['conditions'] = $data['rule']['conditions'];
                unset($data['rule']);
            }
            unset($data['conditions_serialized']);
            unset($data['actions_serialized']);
            
            // Set the model data
            $model->loadPost($data);
            $persister = ($model->getApplyFor() == 'item_rule') ? 'catalog_rule' : 'sale_rule';
            $this->backendSession->setPageData($data);
            $this->dataPersistor->set($persister, $data);
            $model->save();

            $this->messageManager->addSuccessMessage(__('Data Saved Successfully.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Something went wrong while saving the rule.'));
            return $resultRedirect->setPath('*/*/addcartrule');
        }

        return $resultRedirect->setPath('*/*/index');
    }

    /**
     * Authorization level
     *
     * @see _isAllowed()
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Vdcstore_FreeGift::managerules_save');
    }
}
