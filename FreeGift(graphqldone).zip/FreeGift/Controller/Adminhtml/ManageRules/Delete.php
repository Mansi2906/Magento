<?php
namespace Vdcstore\FreeGift\Controller\Adminhtml\ManageRules;

use Vdcstore\FreeGift\Model\RulesFactory;

class Delete extends \Magento\Backend\App\Action
{
    /**
     * @var RulesFactory
     */
    protected $rulefactory;

    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param RulesFactory $rulefactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        RulesFactory $rulefactory
    ) {
        $this->rulefactory = $rulefactory;
        parent::__construct($context);
    }

    /**
     * Execute method for delete job
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('entity_id');
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            $title = "";
            try {
                $model = $this->rulefactory->create();
                $model->load($id);

                $title = $model->getName();
                $model->delete();
                $this->messageManager->addSuccess(__('The Rule has been deleted.'));

                $this->_eventManager->dispatch(
                    'adminhtml_rule_on_delete',
                    ['title' => $title, 'status' => 'success']
                );
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->_eventManager->dispatch(
                    'adminhtml_rule_on_delete',
                    ['title' => $title, 'status' => 'fail']
                );
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/addcartrule', ['entity_id' => $id]);
            }
        }
        $this->messageManager->addError(__('We can\'t find a Rule to delete.'));
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Authorization level
     *
     * @see _isAllowed()
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Vdcstore_FreeGift::managerules_delete');
    }
}
