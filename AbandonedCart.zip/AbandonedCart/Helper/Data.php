<?php

namespace Vdcstore\AbandonedCart\Helper;

use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\Store;

class Data extends AbstractHelper
{
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Data constructor.
     *
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig
        ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Get configuration value by path
     *
     * @param string $path
     * @param string $scopeType
     * @param string|null $scopeCode
     * @return mixed
     */
    protected function getConfigValue($path, $scopeType = ScopeInterface::SCOPE_STORE, $scopeCode = null)
    {
        return $this->scopeConfig->getValue($path, $scopeType, $scopeCode);
    }

    /**
     * Get 'abandonedcart/general/enable' configuration value
     *
     * @return mixed
     */
    public function isAbandonedCartEnabled()
    {
        return $this->getConfigValue('abandonedcart/general/enable');
    }

    /**
     * Get 'abandonedcart/email/send_after' configuration value
     *
     * @return string
     */
    public function getSendAfterConfig()
    {
        return $this->getConfigValue('abandonedcart/email/send_after');
    }
    
    /**
     * Get 'abandonedcart/email/template' configuration value
     *
     * @return string
     */
    public function getEmailConfig()
    {
        return $this->getConfigValue('abandonedcart/email/template');
    }

    /**
     * Get 'abandonedcart/email/sender' configuration value
     *
     * @return string
     */
    public function getSender()
    {
        return $this->getConfigValue('abandonedcart/email/sender');
    }
}
