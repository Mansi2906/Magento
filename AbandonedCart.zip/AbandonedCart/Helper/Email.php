<?php

namespace Vdcstore\AbandonedCart\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Escaper;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\UrlInterface;
use Vdcstore\AbandonedCart\Helper\Data as AbandonedCartData;
use Vdcstore\AbandonedCart\Block\Email\Template as EmailTemplate;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Api\StoreRepositoryInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\QuoteFactory;
use \Psr\Log\LoggerInterface;

/**
 * Class Email
 * Handles email sending related to abandoned carts.
 *
 */
class Email extends \Magento\Framework\App\Helper\AbstractHelper
{
     /**
      * @var StateInterface
      */
    protected $inlineTranslation;

    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @var TransportBuilder
     */
    protected $transportBuilder;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var AbandonedCartData
     */
    protected $abandonedCartData;

    /**
     * @var EmailTemplate
     */
    protected $emailTemplate;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var StoreRepositoryInterface
     */
    private $storeRepository;

    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    protected $quoteRepository;

    /**
     * Email constructor.
     *
     * @param Context $context
     * @param StateInterface $inlineTranslation
     * @param Escaper $escaper
     * @param TransportBuilder $transportBuilder
     * @param CheckoutSession $checkoutSession
     * @param CustomerRepositoryInterface $customerRepository
     * @param UrlInterface $urlBuilder
     * @param AbandonedCartData $abandonedCartData
     * @param EmailTemplate $emailTemplate
     * @param StoreManagerInterface $storeManager
     * @param StoreRepositoryInterface $storeRepository
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     * @param LoggerInterface $logger
     */

    public function __construct(
        Context $context,
        StateInterface $inlineTranslation,
        Escaper $escaper,
        TransportBuilder $transportBuilder,
        CheckoutSession $checkoutSession,
        CustomerRepositoryInterface $customerRepository,
        UrlInterface $urlBuilder,
        AbandonedCartData $abandonedCartData,
        EmailTemplate $emailTemplate,
        StoreManagerInterface $storeManager,
        StoreRepositoryInterface $storeRepository,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->inlineTranslation = $inlineTranslation;
        $this->escaper = $escaper;
        $this->transportBuilder = $transportBuilder;
        $this->logger = $context->getLogger();
        $this->checkoutSession = $checkoutSession;
        $this->customerRepository = $customerRepository;
        $this->urlBuilder = $urlBuilder;
        $this->abandonedCartData = $abandonedCartData;
        $this->emailTemplate = $emailTemplate;
        $this->storeManager = $storeManager;
        $this->storeRepository = $storeRepository;
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
    }

    /**
     * Sends an email regarding abandoned cart.
     *
     * @param array $emailData Data required for sending email
     */
    public function sendEmail($emailData)
    {
        // Extract data from $emailData
        $customerEmail = $emailData['email'];
        $firstName = $emailData['first_name'];
        $lastName = $emailData['last_name'];
        $quoteId = $emailData['quote_id'];
        $quote = $this->quoteRepository->get($quoteId);
        // Extract store_id
        $storeId = $quote->getStoreId();
        
            // Load the store by store_id to get the store name
        try {
            $store = $this->storeManager->getStore($storeId);
            $storeName = $store->getName();
        } catch (\Exception $e) {
            $this->logger->error('Error retrieving store: ' . $e->getMessage());
        }
    
        $sender = $this->abandonedCartData->getSender();
        $emailTemplateId = $this->abandonedCartData->getEmailConfig();

        // Generate Cart URL
        $cartUrl = $this->urlBuilder->getUrl('checkout/cart');
        $url = $cartUrl;

        // Get the current store from the checkout session
        $quote = $this->checkoutSession->getQuote();

        try {
            $this->inlineTranslation->suspend();

            $senderInfo = [
                'name' => $this->escaper->escapeHtml('Owner'),
                'email' => $sender
            ];

            $transport = $this->transportBuilder
                ->setTemplateIdentifier($emailTemplateId)
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => $storeId, // Use the store ID here
                    ]
                )
                ->setTemplateVars([
                    'templateVar' => $firstName,
                    'products' => $quoteId,
                    'url' => $url,
                    'store_name' => $storeName // Pass the correct store name
                ])
                ->setFrom($senderInfo)
                ->addTo($customerEmail, $firstName . ' ' . $lastName)
                ->getTransport();
            
            $transport->sendMessage();
            $this->inlineTranslation->resume();
        } catch (\Exception $e) {
            $this->logger->error('Error sending email: ' . $e->getMessage());
        }
    }
    /**
     * Retrieve the current store ID.
     *
     * @return int
     */
    public function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }
}
