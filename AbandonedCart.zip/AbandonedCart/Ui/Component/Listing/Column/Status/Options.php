<?php

namespace Vdcstore\AbandonedCart\Ui\Component\Listing\Column\Status;

use Magento\Framework\Data\OptionSourceInterface;

class Options implements OptionSourceInterface
{
    /**
     * Retrieve available options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'Wait for send', 'label' => __('Wait for send')],
            ['value' => 'Sent', 'label' => __('Sent')],
            ['value' => 'Success', 'label' => __('Success')]
        ];
    }
}
