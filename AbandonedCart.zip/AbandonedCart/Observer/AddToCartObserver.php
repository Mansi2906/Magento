<?php

namespace Vdcstore\AbandonedCart\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Vdcstore\AbandonedCart\Helper\Email;
use Vdcstore\AbandonedCart\Helper\Data as AbandonedCartData;
use Vdcstore\AbandonedCart\Model\AbandonedCartFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\GroupRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Store\Api\StoreRepositoryInterface;
use \Psr\Log\LoggerInterface;

/**
 * Class AddToCartObserver
 *
 * Observer for handling abandoned cart events.
 */
class AddToCartObserver implements ObserverInterface
{
    /**
     * @var Email
     */
    private $helperEmail;

    /**
     * @var AbandonedCartData
     */
    protected $abandonedCartData;

    /**
     * @var AbandonedCartFactory
     */
    protected $abandonedCartFactory;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     * @var GroupRepositoryInterface
     */
    protected $groupRepository;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var TimezoneInterface
     */
    private $timezone;

    /**
     * @var StoreRepositoryInterface
     */
    private $storeRepository;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * AddToCartObserver constructor.
     *
     * @param TimezoneInterface $timezone
     * @param Email $helperEmail
     * @param AbandonedCartData $abandonedCartData
     * @param AbandonedCartFactory $abandonedCartFactory
     * @param CheckoutSession $checkoutSession
     * @param CustomerRepositoryInterface $customerRepository
     * @param GroupRepositoryInterface $groupRepository
     * @param StoreManagerInterface $storeManager
     * @param StoreRepositoryInterface $storeRepository
     * @param LoggerInterface $logger
     */

    public function __construct(
        TimezoneInterface $timezone,
        Email $helperEmail,
        AbandonedCartData $abandonedCartData,
        AbandonedCartFactory $abandonedCartFactory,
        CheckoutSession $checkoutSession,
        CustomerRepositoryInterface $customerRepository,
        GroupRepositoryInterface $groupRepository,
        StoreManagerInterface $storeManager,
        StoreRepositoryInterface $storeRepository,
        LoggerInterface $logger
    ) {
        $this->timezone = $timezone;
        $this->helperEmail = $helperEmail;
        $this->abandonedCartData = $abandonedCartData;
        $this->abandonedCartFactory = $abandonedCartFactory;
        $this->checkoutSession = $checkoutSession;
        $this->customerRepository = $customerRepository;
        $this->groupRepository = $groupRepository;
        $this->storeManager = $storeManager;
        $this->storeRepository = $storeRepository;
        $this->logger = $logger;
    }

    /**
     * Execute the observer.
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $current_time = $this->timezone->date()->format('Y-m-d H:i:s');
        $quote = $this->checkoutSession->getQuote();
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
    $logger = new \Zend_Log();
    $logger->addWriter($writer);

    $logger->info('----------------- get quote id --------------- ');
    $logger->info(print_r($quote->getId(),true));  
        
        if ($quote) {
            $cartItems = [];
            foreach ($quote->getAllItems() as $item) {
                $cartItems[] = [
                    'product_id' => $item->getProductId(),
                    'name' => $item->getName(),
                    'qty' => $item->getQty(),
                    'price' => $item->getPrice(),
                    'sku' => $item->getSku()
                ];
            }
        }
        if (!$quote || !$quote->getCustomerId()) {
            return; // Skip if no quote id or not a logged-in user
        }


        if (!$quote || !$quote->getId()) {
            $logger->info('----------------- Quote is missing or quote ID is blank. Data will not be saved --------------- ');
            return; // Skip if no quote id or not a logged-in user
        }

        $quoteID = $quote->getId();
        // Get the current store ID from the quote
        $storeId = $quote->getStoreId();
        $store = $this->storeManager->getStore($storeId);

        // Prepare the store hierarchy
        $storeHierarchy = [];
        $websiteId = $store->getWebsiteId();
        $website = $this->storeManager->getWebsite($websiteId);

        // Log the names as per your request
        $storeHierarchy[] = $website->getName(); // Main Website
        $storeHierarchy[] = '   ' . $store->getName(); // Store View Name
        $customerId = $quote->getCustomerId();
        try {
            $customer = $this->customerRepository->getById($customerId);
            $customerGroupId = $customer->getGroupId();
            $customerGroup = $this->groupRepository->getById($customerGroupId);
            $customerGroupName = $customerGroup->getCode();

            $customerData = [
                'customer_id' => $customer->getId(),
                'email' => $customer->getEmail(),
                'firstname' => $customer->getFirstname(),
                'lastname' => $customer->getLastname(),
                'customer_group' => $customerGroupName
            ];
            // Prepare data for saving
            $dataToSave = [
                'quote_id' => $quoteID,
                'store_view' => implode("\n ,", $storeHierarchy),
                'customer_firstname' => $customerData['firstname'],
                'customer_lastname' => $customerData['lastname'],
                'customer_email' => $customerData['email'],
                'customer_group' => $customerData['customer_group'],
                'status' => 'Wait for send',
                'created_at' => $current_time,
                'send_after' => $this->abandonedCartData->getSendAfterConfig()
            ];


            if (empty($quoteID)) {
                $logger->info('Quote ID is empty, data will not be saved.');
                return; // Exit early if quote_id is empty
            }
            // Save data to the table
            $abandonedCart = $this->abandonedCartFactory->create();
            $existingEntry = $abandonedCart->load($quoteID, 'quote_id');

            if ($existingEntry->getId()) {
                $existingEntry->addData($dataToSave);
                $existingEntry->save();
            } else {
                $abandonedCart->setData($dataToSave);
                $abandonedCart->save();
            }
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->error('Customer not found: ' . $e->getMessage());
        } catch (\Exception $e) {
            $this->logger->error('Error processing the quote: ' . $e->getMessage());
        }
    }
}
