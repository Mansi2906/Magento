define([
    'underscore',
    'Magento_Ui/js/grid/columns/select'
], function (_, Column) {
    'use strict';

    return Column.extend({
        defaults: {
            bodyTmpl: 'Vdcstore_AbandonedCart/ui/grid/cells/text'
        },
        getStatusColor: function (row) {            
            if (row.status == 'Wait for send') {
                return 'order-pending';
            }else if(row.status == 'Sent') {
                return 'order-processing';
            }else if(row.status == 'Success') {
                return 'order-complete';
            }
            return '#303030';
        }
    });
});

