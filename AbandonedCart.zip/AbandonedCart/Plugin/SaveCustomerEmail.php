<?php

namespace Vdcstore\AbandonedCart\Plugin;

use Magento\Customer\Model\AccountManagement as CustomerAccountManagement;
use Magento\Framework\Exception\LocalizedException;
use Magento\Checkout\Model\Session as CheckoutSession;
use Vdcstore\AbandonedCart\Helper\Data as AbandonedCartData;
use Vdcstore\AbandonedCart\Model\AbandonedCartFactory;
use Magento\Customer\Api\GroupRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Store\Api\StoreRepositoryInterface;
use \Psr\Log\LoggerInterface;

/**
 * Class SaveCustomerEmail
 * Plugin to modify customer email availability check and save abandoned cart data.
 */
class SaveCustomerEmail
{
   /**
    * @var CheckoutSession
    */
    protected $checkoutSession;

    /**
     * @var AbandonedCartData
     */
    protected $abandonedCartData;

    /**
     * @var AbandonedCartFactory
     */
    protected $abandonedCartFactory;

    /**
     * @var GroupRepositoryInterface
     */
    protected $groupRepository;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;

    /**
     * @var CartRepositoryInterface
     */
    protected $cartRepository;

    /**
     * @var StoreRepositoryInterface
     */
    private $storeRepository;

    /**
     * SaveCustomerEmail constructor.
     *
     * @param TimezoneInterface $timezone
     * @param CheckoutSession $checkoutSession
     * @param AbandonedCartData $abandonedCartData
     * @param AbandonedCartFactory $abandonedCartFactory
     * @param GroupRepositoryInterface $groupRepository
     * @param StoreManagerInterface $storeManager
     * @param CartRepositoryInterface $cartRepository
     * @param StoreRepositoryInterface $storeRepository
     * @param LoggerInterface $logger
     */

    public function __construct(
        TimezoneInterface $timezone,
        CheckoutSession $checkoutSession,
        AbandonedCartData $abandonedCartData,
        AbandonedCartFactory $abandonedCartFactory,
        GroupRepositoryInterface $groupRepository,
        StoreManagerInterface $storeManager,
        CartRepositoryInterface $cartRepository,
        StoreRepositoryInterface $storeRepository,
        LoggerInterface $logger
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->abandonedCartData = $abandonedCartData;
        $this->abandonedCartFactory = $abandonedCartFactory;
        $this->groupRepository = $groupRepository;
        $this->storeManager = $storeManager;
        $this->timezone = $timezone;
        $this->cartRepository = $cartRepository;
        $this->storeRepository = $storeRepository;
        $this->logger = $logger;
    }

    /**
     * After plugin for checking if email is available.
     *
     * @param CustomerAccountManagement $subject
     * @param bool $result
     * @param string $customerEmail
     * @return bool
     * @throws LocalizedException
     */
    public function afterIsEmailAvailable(CustomerAccountManagement $subject, $result, $customerEmail)
    {
        if (!$result) {
            return $result; // Email is not available, do nothing
        }

        $quote = $this->checkoutSession->getQuote();

        if (!$quote || $quote->getCustomerId()) {
            return $result; // No quote found or user is logged in
        }

        $cartId = $quote->getId();

        if (!$cartId || $quote->getCustomerEmail() === $customerEmail) {
            return $result;
        }

        /** @var Quote $quote */
        $quote = $this->cartRepository->getActive($cartId);
        $quote->setCustomerEmail($customerEmail);

        // Get the current store ID from the quote
        $storeId = $quote->getStoreId();
        $store = $this->storeManager->getStore($storeId);

        // Prepare the store hierarchy
        $storeHierarchy = [];
        $websiteId = $store->getWebsiteId();
        $website = $this->storeManager->getWebsite($websiteId);

        // Log the names as per your request
        $storeHierarchy[] = $website->getName(); // Main Website
        $storeHierarchy[] = '   ' . $store->getName(); // Store View Name
        $current_time = $this->timezone->date()->format('Y-m-d H:i:s');

        try {
            $this->cartRepository->save($quote);
        } catch (\Exception $e) {
            $this->logger->error('Error saving quote: ' . $e->getMessage());
            return false;
        }

        // Retrieve customer group name
        $customerGroupId = $quote->getCustomerGroupId();
        $customerGroupName = 'Guest'; // Default for guests
        if ($customerGroupId) {
            try {
                $customerGroup = $this->groupRepository->getById($customerGroupId);
                $customerGroupName = $customerGroup->getCode();
            } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
                $this->logger->error('Customer group not found: ' . $e->getMessage());
            }
        }

        // Prepare customer data for saving
        $dataToSave = [
            'quote_id' => $quote->getId(),
            'store_view' => implode("\n ,", $storeHierarchy),
            'customer_email' => $customerEmail,
            'customer_firstname' => 'Guest',
            'customer_lastname' => 'User',
            'customer_group' => $customerGroupName,
            'status' => 'Wait for send',
            'created_at' => $current_time,
            'send_after' => $this->abandonedCartData->getSendAfterConfig(),
        ];
        // Save data to the table
        try {
            $abandonedCart = $this->abandonedCartFactory->create();
            $existingEntry = $abandonedCart->load($quote->getId(), 'quote_id');

            if ($existingEntry->getId()) {
                // Update existing entry
                $existingEntry->addData($dataToSave);
                $existingEntry->save();
            } else {
                // Save new entry
                $abandonedCart->setData($dataToSave);
                $abandonedCart->save();
            }
        } catch (\Exception $e) {
            // Log error if needed
            $this->logger->error('Error saving abandoned cart data: ' . $e->getMessage());
        }

        return $result; // Email is available
    }
}
