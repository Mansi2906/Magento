<?php

namespace Vdcstore\AbandonedCart\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Framework\View\LayoutFactory;

/**
 * Class View
 * Handles the view action for abandoned carts in the admin panel.
 *
 */
class View extends \Magento\Backend\App\Action
{
    /**
     * @var RawFactory
     */
    protected $resultRawFactory;

    /**
     * @var LayoutFactory
     */
    protected $layoutFactory;

    /**
     * View constructor.
     *
     * @param Context $context
     * @param RawFactory $resultRawFactory
     * @param LayoutFactory $layoutFactory
     */
    public function __construct(
        Context $context,
        RawFactory $resultRawFactory,
        LayoutFactory $layoutFactory
    ) {
        $this->resultRawFactory = $resultRawFactory;
        $this->layoutFactory = $layoutFactory;
        parent::__construct($context);
    }

    /**
     * Execute action to render the view block.
     *
     * @return \Magento\Framework\Controller\Result\Raw
     */
    public function execute()
    {
        $entityId = $this->getRequest()->getParam('entity_id'); // Get entity_id from request
        $layout = $this->layoutFactory->create();
        $block = $layout->createBlock(\Vdcstore\AbandonedCart\Block\Adminhtml\View::class);
        
        $resultRaw = $this->resultRawFactory->create();
        return $resultRaw->setContents($block->toHtml());
    }
}
