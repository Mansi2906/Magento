<?php
namespace Vdcstore\AbandonedCart\Block\Email;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Helper\Image;

/**
 * Class Template
 * Block for rendering email templates related to abandoned carts.
 */
class Template extends \Magento\Framework\View\Element\Template
{
   /**
    * @var int|null
    */
    protected $quoteId;

    /**
     * @var QuoteRepository
     */
    protected $quoteRepository;

    protected $productRepository;
    protected $imageHelper;


    /**
     * Template constructor.
     *
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param QuoteRepository $quoteRepository
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Quote\Model\QuoteRepository $quoteRepository,
        ProductRepositoryInterface $productRepository,
        Image $imageHelper,
        array $data = []
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->productRepository = $productRepository;
        $this->imageHelper = $imageHelper;
        parent::__construct($context, $data);
    }

     /**
      * Set the quote ID.
      *
      * @param int $quoteId
      * @return $this
      */
    public function setQuoteId($quoteId)
    {
        $this->quoteId = $quoteId;
        return $this;
    }

    /**
     * Retrieve items from the quote by ID.
     *
     * @param int $quoteId
     * @return \Magento\Quote\Model\Quote\Item[]
     */
    public function getQuoteItems($quoteId)
    {
        try {
            $quote = $this->quoteRepository->get($quoteId);
            $items = $quote->getAllItems();
            return $items;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            return [];
        }
    }

     public function getProductImageUrl($productId)
    {
        try {
            // Load the product by ID
            $product = $this->productRepository->getById($productId);

            // Get the product image URL (base image in this example)
            $imageUrl = $this->imageHelper->init($product, 'product_base_image')->getUrl();
            return $imageUrl;
        } catch (NoSuchEntityException $e) {
            // Handle case where product does not exist
            return '';
        }
    }
}
