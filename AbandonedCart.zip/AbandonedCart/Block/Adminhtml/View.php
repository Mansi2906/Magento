<?php
namespace Vdcstore\AbandonedCart\Block\Adminhtml;

use Magento\Backend\Block\Template;
use Magento\Backend\Block\Template\Context;
use Vdcstore\AbandonedCart\Model\ResourceModel\AbandonedCart\CollectionFactory;
use Vdcstore\AbandonedCart\Block\Email\Template as EmailTemplate;

/**
 * Class View
 * Block for rendering the admin view of abandoned carts.
 */
class View extends Template
{
    /**
     * @var string
     */
    protected $_template = 'Vdcstore_AbandonedCart::view.phtml';

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var EmailTemplate
     */
    protected $emailTemplate;

    /**
     * View constructor.
     *
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param EmailTemplate $emailTemplate
     * @param array $data
     */

    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        EmailTemplate $emailTemplate, // Inject Email Template
        array $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->emailTemplate = $emailTemplate; // Initialize Email Template
        parent::__construct($context, $data);
    }

     /**
      * Get the abandoned cart collection.
      *
      * @return \Vdcstore\AbandonedCart\Model\ResourceModel\AbandonedCart\Collection
      */
    public function getCollection()
    {
        $entityId = $this->getRequest()->getParam('entity_id');
        $collection = $this->collectionFactory->create();

        if ($entityId) {
            $collection->addFieldToFilter('entity_id', $entityId);
        }

        $collection->setPageSize(1);
        return $collection;
    }

     /**
      * Get quote items by quote ID.
      *
      * @param int $quoteId
      * @return \Magento\Quote\Model\Quote\Item[]
      */
    public function getQuoteItems($quoteId)
    {
        return $this->emailTemplate->getQuoteItems($quoteId); // Call getQuoteItems method
    }
}
