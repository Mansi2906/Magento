<?php
namespace Vdcstore\AbandonedCart\Block\Adminhtml;

class Selector extends \Magento\Backend\Block\Template
{
}
