<?php

namespace Vdcstore\AbandonedCart\Block;

use Magento\Framework\View\Element\Template;
use Vdcstore\AbandonedCart\Helper\Data;
use Magento\Store\Model\StoreManagerInterface;

class Config extends Template
{
    /**
     * @var Data
     */
    protected $helper;
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * Config constructor.
     *
     * @param Template\Context $context
     * @param Data $helper
     * @param StoreManagerInterface $storeManager
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $helper,
        StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->storeManager = $storeManager;
        parent::__construct($context, $data);
    }

    /**
     * Check if abandoned cart is enabled.
     *
     * @return bool
     */
    public function isAbandonedCartEnabled()
    {
        return $this->helper->isAbandonedCartEnabled();
    }

    /**
     * Get the email configuration.
     *
     * @return mixed
     */
    public function getEmailConfig()
    {
        return $this->helper->getEmailConfig();
    }

     /**
      * Get the send after configuration
      *
      * @return string
      */
    public function getSendAfterConfig()
    {
        return $this->helper->getSendAfterConfig();
    }

    /**
     * Get the sender configuration.
     *
     * @return string
     */
    public function getSender()
    {
        return $this->helper->getSender();
    }
}
