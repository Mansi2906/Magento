<?php

namespace Vdcstore\AbandonedCart\Cron;

use Vdcstore\AbandonedCart\Helper\Data as AbandonedCartData;
use Vdcstore\AbandonedCart\Helper\Email;
use Vdcstore\AbandonedCart\Model\ResourceModel\AbandonedCart\CollectionFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use \Psr\Log\LoggerInterface;

/**
 * Class SendAbandonedCartEmail
 * Cron job to send emails for abandoned carts.
 */
class SendAbandonedCartEmail
{
    /**
     * @var AbandonedCartData
     */
    protected $abandonedCartData;

    /**
     * @var Email
     */
    private $helperEmail;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $quoteRepository;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * SendAbandonedCartEmail constructor.
     *
     * @param AbandonedCartData $abandonedCartData
     * @param Email $helperEmail
     * @param CollectionFactory $collectionFactory
     * @param TimezoneInterface $timezone
     * @param \Magento\Quote\Model\QuoteRepository $quoteRepository
     * @param LoggerInterface $logger
     */

    public function __construct(
        AbandonedCartData $abandonedCartData,
        Email $helperEmail,
        CollectionFactory $collectionFactory,
        TimezoneInterface $timezone,
        \Magento\Quote\Model\QuoteRepository $quoteRepository,
        LoggerInterface $logger
    ) {
        $this->abandonedCartData = $abandonedCartData;
        $this->helperEmail = $helperEmail;
        $this->timezone = $timezone;
        $this->collectionFactory = $collectionFactory;
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
    }

    /**
     * Execute the cron job to send abandoned cart emails.
     */
    public function execute()
    {
        // Retrieve the configuration value for sending email after
        $sendAfter = $this->abandonedCartData->getSendAfterConfig();

        // Get the current time
        $current_time = $this->timezone->date()->format('Y-m-d H:i:s');

        // Convert send_after configuration to a DateTime interval
        $sendAfterInterval = (int)$sendAfter; // Assuming send_after is in minutes
        $sendAfterDateTime = (new \DateTime($current_time))->modify("-$sendAfterInterval minutes");
    
        // Convert DateTime to string format for filtering
        $filterDateTime = $sendAfterDateTime->format('Y-m-d H:i:s');
    
        // Create collection and add filters
        $collection = $this->collectionFactory->create();
        $collection->addFieldToFilter('created_at', ['lteq' => $filterDateTime])
                    ->addFieldToFilter('status', ['eq' => 'Wait for send']);
                    
        // Log number of records found
        $recordCount = $collection->getSize();

        if ($recordCount > 0) {
            foreach ($collection as $item) {
                $createdAt = $item->getCreatedAt();
                $entityId = $item->getId(); // Use entity_id for identification
    
                // Extract email data from the item
                $emailData = [
                    'email' => $item->getCustomerEmail(),
                    'first_name' => $item->getCustomerFirstname(),
                    'last_name' => $item->getCustomerLastname(),
                    'quote_id' => $item->getQuoteId(),
                ];
                
                $quoteId = $item->getQuoteId();
                $quote = $this->quoteRepository->get($quoteId);
                $isActive = $quote->getIsActive();
                $itemsCount = $quote->getItemsCount(); // Get the number of items in the cart
    
                // Check if the quote is active (is_active = 1) and has items
                if ($isActive == 1 && $itemsCount > 0) {
                    try {
                        // Send email for the abandoned cart
                        $sendEmail = $this->helperEmail->sendEmail($emailData);

                        // Update the status to "Sent"
                        $item->setStatus('Sent');
                        $item->save();
                    } catch (\Exception $e) {
                        $this->logger->error('Error sending email or updating status: ' . $e->getMessage());
                    }
                }
            }
        }
    
    // Now handle records with status "Sent" or "Wait for send" and isActive = 0
        $sentCollection = $this->collectionFactory->create();
        $sentCollection->addFieldToFilter('status', ['in' => ['Sent', 'Wait for send']]);
    
        $sentRecordCount = $sentCollection->getSize();
        if ($sentRecordCount > 0) {
            foreach ($sentCollection as $item) {
                $quoteId = $item->getQuoteId();
                $quote = $this->quoteRepository->get($quoteId);
                $isActive = $quote->getIsActive();
                $itemsCount = $quote->getItemsCount(); // Get the number of items in the cart
                if ($isActive == 0 && $itemsCount > 0) {
                    $item->setStatus('Success');
                    $item->save();
                }
            }
        }
    }
}
