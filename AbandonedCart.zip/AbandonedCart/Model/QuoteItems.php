<?php
namespace  Vdcstore\AbandonedCart\Model;

/**
 * Class QuoteItems
 * Handles retrieval of quote items from the quote repository.
 */
class QuoteItems
{
    /**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $quoteRepository;

    /**
     * QuoteItems constructor.
     *
     * @param \Magento\Quote\Model\QuoteRepository $quoteRepository
     */
    public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository
    ) {
        $this->quoteRepository = $quoteRepository;
    }
    
    /**
     * Retrieve all items for a given quote ID.
     *
     * @param int $quoteId
     * @return \Magento\Quote\Model\Quote\Item[]
     */
    public function getQuoteItems($quoteId)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        try {
            $quote = $this->quoteRepository->get($quoteId);
            $items = $quote->getAllItems();
            $logger->info('----------------- get daata  from model--------------- ');
            $logger->info(print_r($items,true)); 

            return $items;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $logger->info('----------------- get daata catch from model--------------- ');

            return [];
        }

    }
}
