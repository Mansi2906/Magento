<?php

namespace Vdcstore\AbandonedCart\Model\Source;

use function __;

class SendAfter implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Get Function
     *
     * @return array[]
     */
    public function toOptionArray(): array
    {
        return [
        ['value' => '1m', 'label' => __('1m')],
            ['value' => '30m', 'label' => __('30m')],
            ['value' => '60m', 'label' => __('1h')],
            ['value' => '120m', 'label' => __('2h')],
            ['value' => '240m', 'label' => __('4h')],
            ['value' => '360m', 'label' => __('6h')],
            ['value' => '480m', 'label' => __('8h')],
            ['value' => '720m', 'label' => __('12h')],
            ['value' => '1440m', 'label' => __('24h')],
        ];
    }
}
