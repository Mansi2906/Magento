<?php

namespace Vdcstore\AbandonedCart\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class AbandonedCart
 * Resource model for the Abandoned Cart entity.
 */
class AbandonedCart extends AbstractDb
{
    /**
     * Initialize the resource model.
     */
    protected function _construct()
    {
        $this->_init('vdc_abandoned_cart_email_schedule', 'entity_id');
    }
}
