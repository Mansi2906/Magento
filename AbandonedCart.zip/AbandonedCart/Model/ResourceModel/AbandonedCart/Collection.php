<?php

namespace Vdcstore\AbandonedCart\Model\ResourceModel\AbandonedCart;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * Collection class for managing AbandonedCart models.
 */
class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';

    /**
     * Initialize the model and resource model.
     */
    protected function _construct()
    {
        $this->_init(
            'Vdcstore\AbandonedCart\Model\AbandonedCart', // Model class
            'Vdcstore\AbandonedCart\Model\ResourceModel\AbandonedCart' // Resource model class
        );
    }
}
