<?php

namespace Vdcstore\AbandonedCart\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class AbandonedCart
 * Model for handling abandoned cart data.
 */
class AbandonedCart extends AbstractModel
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';
    
    /**
     * Initialize the abandoned cart model.
     */
    protected function _construct()
    {
        $this->_init('Vdcstore\AbandonedCart\Model\ResourceModel\AbandonedCart');
    }
}
