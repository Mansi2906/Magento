<?php
namespace VDC\HelloWorld\Observer;

use Magento\Framework\Event\ObserverInterface;
use VDC\HelloWorld\Helper\Email;


class CheckoutObserver implements ObserverInterface
{
    private $helperEmail;
    
    public function __construct(
        Email $helperEmail
    ) {
        $this->helperEmail = $helperEmail;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        // $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        // $logger = new \Zend_Log();
        // $logger->addWriter($writer);
        // $logger->info('-------helooooo-------');  
        return $this->helperEmail->CheckoutEmail();


        
    }
}