<?php

namespace VDC\HelloWorld\Controller\Index;

class Config extends \Magento\Framework\App\Action\Action
{

	protected $helperData;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\VDC\HelloWorld\Helper\Data $helperData

	)
	{
		$this->helperData = $helperData;
		return parent::__construct($context);
	}

	public function execute()
	{
		

		// TODO: Implement execute() method.

		echo 'Enabale and disable:<br>' . $this->helperData->getGeneralConfig('enable');
        echo '<br>';
        echo '<br>';
		echo 'Text field text:<br>' . $this->helperData->getGeneralConfig('display_text');
        echo '<br>';
        echo '<br>';
        echo 'Textarea discription:<br>' . $this->helperData->getGeneralConfig('textarea_example');
        echo '<br>';
        echo '<br>';
        echo 'Selected country:<br>' . $this->helperData->getGeneralConfig('dropdown_example');
        echo '<br>';
        echo '<br>';
        echo 'Multiselected cities:<br>' . $this->helperData->getGeneralConfig('multiselect_example');
		echo '<br>';
		echo '<br>';
		echo 'Multiselected Products:<br>' . $this->helperData->getGeneralConfig('multiselect_product');
    	echo '<br>';
		echo '<br>';

		// echo '<h3>Custom data:</h3>';
		// echo 'Enabale and disable:<br>' . $this->helperData->getDataConfig('enable');
        // echo '<br>'; 
		// echo '<br>';
		// echo 'Alphanumeric values:<br>' . $this->helperData->getDataConfig('display_alpha');
        // echo '<br>';
        // echo '<br>';
        // echo 'Number values:<br>' . $this->helperData->getDataConfig('display_num');
        // echo '<br>';
        // echo '<br>';
        // echo 'Multiselected Customer Group:<br>' . $this->helperData->getDataConfig('multiselect_customer_grp');
        // echo '<br>';
        // echo '<br>';
        // echo 'Select city:<br>' . $this->helperData->getDataConfig('dropdown_select');
		// echo '<br>';
		// echo '<br>';
		// echo 'Color:<br>' . $this->helperData->getDataConfig('select_color');echo '<br>';
		// echo '<br>';
		// echo 'Image:<br><img src="pub/vdc/banner" >' . $this->helperData->getDataConfig('slider_image');
		
		
		exit();

	}
}