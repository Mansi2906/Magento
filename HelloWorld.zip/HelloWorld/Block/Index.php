<?php

namespace VDC\HelloWorld\Block;

use \Magento\Framework\View\Element\Template;
use \Magento\Framework\View\Element\Template\Context;
use \Magento\Store\Model\StoreManagerInterface;
use \VDC\HelloWorld\Helper\Data;
use \Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\UrlInterface;


class Index extends Template
{
    public function __construct(Context $context, StoreManagerInterface $storeManager, Data $helperData)
    {        
        $this->_storeManager = $storeManager;
        $this->_helperData = $helperData;
        parent::__construct($context);
    }

    public function getGeneralData()
    {
        return $this->_helperData->getGeneralConfig();
    }
    public function getEnable()
    {
        return $this->_helperData->getDataConfig('enable');
    }
    public function getAlpha()
    {

        return $this->_helperData->getDataConfig('display_alpha');
    }
    public function getNum()
    {

        return $this->_helperData->getDataConfig('display_num');
    }
    public function getCustomerGrp()
    {

        return $this->_helperData->getDataConfig('multiselect_customer_grp');
    }
    public function getSelect()
    {

        return $this->_helperData->getDataConfig('dropdown_select');
    }
    public function getColor()
    {

        return $this->_helperData->getDataConfig('select_color');
    }
    public function getImage()
    {
        // $mediaUrl = $this ->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        // return $mediaUrl;
        return $this->_helperData->getDataConfig('image_field');
    }
    public function getMediaPath() {
        return $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]);
    }
    public function getFile()
    {

        return $this->_helperData->getDataConfig('custom_file_upload');
    }


}