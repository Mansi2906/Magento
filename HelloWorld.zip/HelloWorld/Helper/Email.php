<?php
namespace VDC\HelloWorld\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Escaper;
use Magento\Framework\Mail\Template\TransportBuilder;


class Email extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $inlineTranslation;
    protected $escaper;
    protected $transportBuilder;
    protected $logger;

    public function __construct(
        Context $context,
        StateInterface $inlineTranslation,
        Escaper $escaper,
        TransportBuilder $transportBuilder,
    ) {
        parent::__construct($context);
        $this->inlineTranslation = $inlineTranslation;
        $this->escaper = $escaper;
        $this->transportBuilder = $transportBuilder;
        $this->logger = $context->getLogger();
    }
    
    public function sendEmail()
    {
        //current logged in customer name
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        $customerData = $customerSession->getCustomer()->getName();
      
        //cart data
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');
        $items = $cart->getQuote()->getAllItems();
        foreach($items as $item) 
        {
            $name=$item->getName();
            $sku=$item->getSku();
            $qty=$item->getQty();
            $price=$item->getPrice();
        }
        try 
        {
            $this->inlineTranslation->suspend();
        
            $sender = [
                'name' => $this->escaper->escapeHtml('Test'),
                'email' => $this->escaper->escapeHtml('priya@vdcstore.com'),
            ];
            $transport = $this->transportBuilder
                ->setTemplateIdentifier('email_addtocart_template')
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars([
                    'templateVar'  => $customerData,
                    'products' => $name.', '.'sku='.$sku.', '.'qty='.$qty. ', '.'price='.$price.' ',
                ])
                ->setFrom($sender)
                ->addTo('mansi@vdcstore.com')
                ->getTransport();
            
            $transport->sendMessage();
            $this->inlineTranslation->resume();

            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);
    
            $logger->info('from cart');   

        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
            $logger->info('----------------- wrong data --------------- ');
        }
    }




    public function CheckoutEmail()
    {
        //current logged in customer name
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        $customerData = $customerSession->getCustomer()->getName();
      
        //cart data
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');
        $items = $cart->getQuote()->getAllItems();
        
        try 
        {
            $this->inlineTranslation->suspend();
            $data=[];
            foreach($items as $item) 
            {
                $data[]=[
                'Name'=>$item->getName(),
                'Sku'=>$item->getSku(),
                'Qty'=>$item->getQty(),
                'Price'=>$item->getPrice()];
            }
            $sender = [
                'name' => $this->escaper->escapeHtml('Admin'),
                'email' => $this->escaper->escapeHtml('priya@vdcstore.com'),
            ];
            $transport = $this->transportBuilder
                ->setTemplateIdentifier('email_checkout_template')
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars([
                    'templateVar'  => $customerData,
                    'products' => $data
                    
                ])
                ->setFrom($sender)
                ->addTo('mansi@vdcstore.com')
                ->getTransport();
            
            // $transport->sendMessage();
            // $this->inlineTranslation->resume();

            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);
    
            $logger->info('from checkout');   

        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
            $logger->info('----------------- wrong data --------------- ');
        }
    }

   
}