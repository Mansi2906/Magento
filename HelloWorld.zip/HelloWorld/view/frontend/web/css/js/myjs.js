require([
    "jquery"
    ], function($){
    $(document).ready(function() {
        console.log("Hello");
    });
   });