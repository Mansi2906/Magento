<?php

namespace VDC\HelloWorld\Model\Config\Backend;

class File extends \Magento\Config\Model\Config\Backend\File
{
    public function _getAllowedExtensions() {
        // return ['pdf'];
       return ['pdf','svg','jpeg'];
    }
}