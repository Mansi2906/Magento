<?php

//Location: magento2_root/app/code/Vendorname/Extensionname/Model/Config/Source/Custom.php
namespace VDC\HelloWorld\Model\Config\Source;

class MultiselectCity implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'Kabul', 'label' => __('Kabul')],
            ['value' => 'Zaranj', 'label' => __('Zaranj')],
            ['value' => 'Burrel', 'label' => __('Burrel')],
            ['value' => 'Berat', 'label' => __('Berat')],
            ['value' => 'Traun', 'label' => __('Traun')],
            ['value' => 'Alberta', 'label' => __('Alberta')],
            ['value' => 'Ontario', 'label' => __('Ontario')],
            ['value' => 'Bangalore', 'label' => __('Bangalore')],
            ['value' => 'Hyderabad', 'label' => __('Hyderabad')],
            ['value' => 'Ahmedabad', 'label' => __('Ahmedabad')],
            ['value' => 'Jaipur', 'label' => __('Jaipur')],
            ['value' => 'Mumbai', 'label' => __('Mumbai')],
            ['value' => 'Delhi', 'label' => __('Delhi')],
            ['value' => 'Bhopal', 'label' => __('Bhopal')],
            ['value' => 'Raipur', 'label' => __('Raipur')],
            ['value' => 'Chandigarh', 'label' => __('Chandigarh')],


        ];
       
    }
}