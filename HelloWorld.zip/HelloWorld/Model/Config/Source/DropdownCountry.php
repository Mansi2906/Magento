<?php

namespace VDC\HelloWorld\Model\Config\Source;

class DropdownCountry implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {

        // $dropdown=[];

        // $dropdown[]=[
        //     'value' => 'Zero',
        //     'label' => 'Zero'
        // ];
        // $dropdown[]=[
        //     'value' => 'One',
        //     'label' => 'One'
        // ];
        // return $dropdown;
        return [
            ['value' => 'Afghanistan', 'label' => __('Afghanistan')],
            ['value' => 'Albania', 'label' => __('Albania')],
            ['value' => 'Austria', 'label' => __('Austria')],
            ['value' => 'Brazil', 'label' => __('Brazil')],
            ['value' => 'Bahrain', 'label' => __('Bahrain')],
            ['value' => 'Canada', 'label' => __('Canada')],
            ['value' => 'China', 'label' => __('China')],
            ['value' => 'India', 'label' => __('India')],
            ['value' => 'Japan', 'label' => __('Japan')],
            ['value' => 'Maldives', 'label' => __('Maldives')],
            ['value' => 'New Zealand', 'label' => __('New Zealand')],
            ['value' => 'Russia', 'label' => __('Russia')],
        ];
       
    }
}