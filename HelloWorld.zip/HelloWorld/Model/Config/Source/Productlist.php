<?php

namespace VDC\HelloWorld\Model\Config\Source;

class Productlist implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {

    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $productCollection = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection');
    $collection = $productCollection->addAttributeToSelect('sku')->addAttributeToSelect('name');
    $ret = [];
    foreach ($collection as $product){

    $ret[] = [
                'value' => $product->getSku(),
                'label' => $product->getName()
            ];
    } 
    return $ret; 

    }

}