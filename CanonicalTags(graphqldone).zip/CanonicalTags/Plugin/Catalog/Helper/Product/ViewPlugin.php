<?php
namespace Vdcstore\CanonicalTags\Plugin\Catalog\Helper\Product;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Result\Page as ResultPage;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class ViewPlugin
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * ViewPlugin constructor.
     * @param StoreManagerInterface $storeManager
     * @param ProductRepositoryInterface $productRepository
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        ProductRepositoryInterface $productRepository,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->productRepository = $productRepository;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * AfterPrepareAndRender
     *
     * @param mixed $subject
     * @param mixed $result
     * @param ResultPage $resultPage
     * @param mixed $productId
     * @param mixed $controller
     * @param mixed|null $params
     * @return bool
     */
    public function afterPrepareAndRender(
        $subject,
        $result,
        ResultPage $resultPage,
        $productId,
        $controller,
        $params = null
    ) {
        $isEnabled = $this->scopeConfig->getValue(
            'canonicalurl/general/enable',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        try {
            if ($isEnabled == '1') {
                $product = $this->productRepository->getById(
                    $productId,
                    false,
                    $this->storeManager->getStore()->getId()
                );
                /** @var \Magento\Framework\View\Page\Config $pageConfig */
                $pageConfig = $resultPage->getConfig();
                $assets = $pageConfig->getAssetCollection()->getGroups();

                foreach ($assets as $asset) {
                    if ($asset->getProperty('content_type') == 'canonical') {
                        $url = $product->getUrlModel()->getUrl($product, ['_ignore_category' => true]);
                        $pageConfig->getAssetCollection()->remove($url);
                        $newUrl = $product->getData('canonicaltext');
                        // $newUrl = 'hello';
                        if (empty($newUrl)) {
                            $newUrl = $product->getUrlModel()->getUrl($product, ['_ignore_category' => true]);
                        }
                        $pageConfig->addRemotePageAsset(
                            $newUrl,
                            'canonical',
                            ['attributes' => ['rel' => 'canonical']]
                        );
                    }
                }
            }
        } catch (NoSuchEntityException $e) {
            return false;
        }
    }
}
