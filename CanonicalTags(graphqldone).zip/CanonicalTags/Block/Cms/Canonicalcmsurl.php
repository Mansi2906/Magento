<?php
namespace Vdcstore\CanonicalTags\Block\Cms;

use Magento\Framework\View\Element\Template;
use Magento\Cms\Model\PageFactory;

class Canonicalcmsurl extends Template
{
    /**
     * Canonicalcmsurl constructor.
     *
     * @param Template\Context $context
     * @param PageFactory $pageFactory
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        PageFactory $pageFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->pageFactory = $pageFactory;
    }

    /**
     * GetCanonicalurl
     */
    public function getCanonicalurl()
    {
        $cmsPageId = $this->getRequest()->getParam('page_id');
        $page = $this->pageFactory->create()->load($cmsPageId);
        $cmsData = $page->getData('cmscanonical');
        return $cmsData;
    }
}
