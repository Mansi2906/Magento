<?php
namespace Vdcstore\CanonicalTags\Model\Resolver;

use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\View\Element\BlockFactory;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Vdcstore\CanonicalTags\Helper\Data as CanonicalHelper;

class CategoryCanonicalUrl implements ResolverInterface
{
    protected $blockFactory;
    protected $helper;
    /**
     * @var \Magento\Catalog\Helper\Category
     */
    protected $_categoryHelper;

    public function __construct(
        BlockFactory $blockFactory,
        CanonicalHelper $helper,
        \Magento\Catalog\Helper\Category $categoryHelper,
    ) {
        $this->blockFactory = $blockFactory;
        $this->helper = $helper;
        $this->_categoryHelper = $categoryHelper;
    }

    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        
        $isEnabled = $this->helper->getGeneralConfig('enable');
        if (!$isEnabled || !$this->_categoryHelper->canUseCanonicalTag()) {
            throw new GraphQlInputException(__('Please enable Canonical Tags module.'));
        }

        if (!isset($args['category_id'])) {
            throw new GraphQlInputException(__('Category ID is required.'));
        }

        $categoryId = $args['category_id'];

        /** @var \Vdcstore\CanonicalTags\Block\Category\View $block */
        $block = $this->blockFactory->createBlock(\Vdcstore\CanonicalTags\Block\Category\View::class);
        $block->getRequest()->setParams(['category_id' => $categoryId]);

        $canonicalUrl = $block->getCanonicalUrl();

        return [
            'url' => $canonicalUrl ?: 'No canonical URL set',
        ];
    }
}
