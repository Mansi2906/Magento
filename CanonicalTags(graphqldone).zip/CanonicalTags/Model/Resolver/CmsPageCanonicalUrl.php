<?php
namespace Vdcstore\CanonicalTags\Model\Resolver;

use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\View\Element\BlockFactory;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Vdcstore\CanonicalTags\Helper\Data as CanonicalHelper;

class CmsPageCanonicalUrl implements ResolverInterface
{
    protected $blockFactory;
    protected $helper;

    public function __construct(
        BlockFactory $blockFactory,
        CanonicalHelper $helper
    ) {
        $this->blockFactory = $blockFactory;
        $this->helper = $helper;
    }

    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $isEnabled = $this->helper->getGeneralConfig('enable');
        if (!$isEnabled) {
            throw new GraphQlInputException(__('Please enable Canonical Tags module.'));
        }

        if (!isset($args['page_id'])) {
            throw new GraphQlInputException(__('Page ID is required.'));
        }

        $pageId = $args['page_id'];

        /** @var \Vdcstore\CanonicalTags\Block\Cms\Canonicalcmsurl $block */
        $block = $this->blockFactory->createBlock(\Vdcstore\CanonicalTags\Block\Cms\Canonicalcmsurl::class);
        $block->getRequest()->setParams(['page_id' => $pageId]);

        $canonicalUrl = $block->getCanonicalUrl();

        return [
            'url' => $canonicalUrl ?: 'No canonical URL set',
        ];

    }
}
