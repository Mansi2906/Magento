<?php
namespace Vdcstore\CanonicalTags\Model\Resolver;

use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Catalog\Model\ProductRepository;
use Magento\Store\Model\StoreManagerInterface;
use Vdcstore\CanonicalTags\Helper\Data as CanonicalTagsHelper;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;

class ProductCanonicalUrl implements ResolverInterface
{
    protected $productRepository;
    protected $storeManager;
    protected $helper;

    public function __construct(
        ProductRepository $productRepository,
        StoreManagerInterface $storeManager,
        CanonicalTagsHelper $helper
    ) {
        $this->productRepository = $productRepository;
        $this->storeManager = $storeManager;
        $this->helper = $helper;
    }

    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        if (!isset($args['product_id'])) {
            throw new GraphQlInputException(__('Product ID is required.'));
        }

        $useMagentoCanonical = $this->helper->getConfigValue(
            'catalog/seo/product_canonical_tag'
        );
        
        $isEnabled = $this->helper->getGeneralConfig('enable');
        if (!$isEnabled || !$useMagentoCanonical) {
            throw new GraphQlInputException(__('Please enable Canonical Tags module.'));
        }

        try {
            $storeId = $this->storeManager->getStore()->getId();
            $product = $this->productRepository->getById($args['product_id'], false, $storeId);

            $canonicalUrl = $product->getData('canonicaltext');

            if (empty($canonicalUrl)) {
                return ['url' => __('No canonical URL set.')];
            }

            return ['url' => $canonicalUrl];

        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            throw new GraphQlInputException(__('Product not found.'));
        } catch (\Exception $e) {
            throw new GraphQlInputException(__('Unable to retrieve canonical URL.'));
        }
    }
}
