<?php
namespace Vdcstore\CanonicalTags\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    public function getGeneralConfig($code, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            'canonicalurl/general/' . $code,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    
    public function getConfigValue($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}
